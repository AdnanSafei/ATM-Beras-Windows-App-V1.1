﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Threading;

/******************************************************************************
// Author: Husni Fahmi
// Email: husnifahmi@outlook.com
// Company: PT Gria Inovasi Teknologi, https://grit.id/
// Date: 5 January 2021
// Description: ATM Beras Windows .NET Application
// 1. Biodata pribadi
// 2. Init Saldo
// 3. Topup Saldo
// 4. Bagi Beras
// 5. Daftar Lima Transaksi Terakhir
// Smart card: NXP MIFARE Classic 1K S50 Card
******************************************************************************/

namespace Bansos_Masjid_Baiturrahman
{

    public partial class Form1 : Form
    {
        public int retCode, hContext, hCard, Protocol;
        public bool connActive = false;
        public bool autoDet;
        public byte[] SendBuff = new byte[263];
        public byte[] RecvBuff = new byte[263];
        public int SendLen, RecvLen, nBytesRet, reqType, Aprotocol, dwProtocol, cbPciLength;
        public string logFilename = "";

        public StreamWriter swLog;
        UserReg userReg;

        byte[] TransNumberBlocks = new byte[5];

        TransRecord[] transRecords = new TransRecord[5];

        // Transaction Code

        string[] TransCodeString = { "None", "Init Saldo", "Topup Saldo", "Bagi Beras" };

        private void txtNIKTgl_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtNIKTgl_TextChanged(object sender, EventArgs e)
        {
            if (((TextBox)sender).TextLength > 5)
                SendKeys.Send("{Tab}");
        }

        private void txtNIKUrut_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtNIKUrut_TextChanged(object sender, EventArgs e)
        {
            if (((TextBox)sender).TextLength > 3)
                SendKeys.Send("{Tab}");
        }

        private int WriteNIK(string strNIK, ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            byte[] byteNIK = Encoding.ASCII.GetBytes(strNIK);
            swLog.WriteLine("Update Binary NIK: " + strNIK);

            // Write NIK to BLOCK 0x01; Length: 16 bytes

            // Update Binary NIK
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x01;
            SendBuff[4] = 0x10;

            Buffer.BlockCopy(byteNIK, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // swLog.WriteLine("Update Binary NIK");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary NIK.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary NIK.";
                MessageBox.Show("ERROR: Failed to Update Binary NIK.");
                return 1;
            }
            swLog.Flush();

            // Read Binary NIK
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x01; // Block 0x01; NIK
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary NIK");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strNIK2 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary NIK " + strNIK2);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary NIK.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary NIK.";
                MessageBox.Show("ERROR: Failed to Read Binary NIK.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteNIK()

        private int WriteNama(string strNama, ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            string strNama1 = "";
            string strNama2 = "";

            if ( strNama.Length > 16 )
            {
                strNama1 = strNama.Substring(0, 16);
                strNama2 = strNama.Substring(16);

            } else
            {
                strNama1 = strNama;
            }

            byte[] byteNama1 = Encoding.ASCII.GetBytes(strNama1);
            byte[] byteNama2 = Encoding.ASCII.GetBytes(strNama2);

            swLog.WriteLine("Update Binary Nama: " + strNama);

            // strNama maximum lenght: 32 bytes
            // Write first part of Nama to BLOCK 0x02; Length: 16 bytes
            // Write second part of Nama to BLOCK 0x04; Length: 16 bytes

            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x02; // Block 0x02
            SendBuff[4] = 0x10;

            // Block Data
            SendBuff[5] = 0x00;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x00;
            SendBuff[8] = 0x00;
            SendBuff[9] = 0x00;
            SendBuff[10] = 0x00;
            SendBuff[11] = 0x00;
            SendBuff[12] = 0x00;
            SendBuff[13] = 0x00;
            SendBuff[14] = 0x00;
            SendBuff[15] = 0x00;
            SendBuff[16] = 0x00;
            SendBuff[17] = 0x00;
            SendBuff[18] = 0x00;
            SendBuff[19] = 0x00;
            SendBuff[20] = 0x00;

            Buffer.BlockCopy(byteNama1, 0, SendBuff, 5, byteNama1.Length);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Nama1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Nama1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Nama1.";
                MessageBox.Show("ERROR: Failed to Update Binary Nama1.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Nama 1 from Block 0x02
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x02; // // Block 0x02
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Nama1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strNama3 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Nama 1: " + strNama3);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Nama1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Nama1.";
                MessageBox.Show("ERROR: Failed to Read Binary Nama1.");
                return 1;
            }
            swLog.Flush();

            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x04;     // Block Number 0x04
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x04");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x04.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x04.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x04.");
                return 1;
            }
            swLog.Flush();

            // Update Binary Nama 2 to Block 0x04
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x04;     // Block Number 0x04
            SendBuff[4] = 0x10;

            // Block Data
            SendBuff[5] = 0x00;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x00;
            SendBuff[8] = 0x00;
            SendBuff[9] = 0x00;
            SendBuff[10] = 0x00;
            SendBuff[11] = 0x00;
            SendBuff[12] = 0x00;
            SendBuff[13] = 0x00;
            SendBuff[14] = 0x00;
            SendBuff[15] = 0x00;
            SendBuff[16] = 0x00;
            SendBuff[17] = 0x00;
            SendBuff[18] = 0x00;
            SendBuff[19] = 0x00;
            SendBuff[20] = 0x00;

            // MessageBox.Show("byteNama2.Length: " + byteNama2.Length.ToString());
            Buffer.BlockCopy(byteNama2, 0, SendBuff, 5, byteNama2.Length);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Nama2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Nama2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Nama2.";
                MessageBox.Show("ERROR: Failed to Update Binary Nama2.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Nama 2 from Block 0x04
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x04;
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Nama 2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strNama4 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Nama 2: " + strNama4);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Nama2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Nama2.";
                MessageBox.Show("ERROR: Failed to Read Binary Nama2.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteNama()

        private int WriteTempatLahir(string strTempatLahir, ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            string strTempatLahir1 = "";
            string strTempatLahir2 = "";

            byte[] byteTempatLahir1 = new byte[16];
            byte[] byteTempatLahir2 = new byte[16];

            Array.Clear(byteTempatLahir1, 0, 16);
            Array.Clear(byteTempatLahir2, 0, 16);

            if (strTempatLahir.Length > 16)
            {
                strTempatLahir1 = strTempatLahir.Substring(0, 16);
                strTempatLahir2 = strTempatLahir.Substring(16);

                byte[] byteTempatLahirTemp1 = Encoding.ASCII.GetBytes(strTempatLahir1);
                byte[] byteTempatLahirTemp2 = Encoding.ASCII.GetBytes(strTempatLahir2);

                Buffer.BlockCopy(byteTempatLahirTemp1, 0, byteTempatLahir1, 0, 16);
                Buffer.BlockCopy(byteTempatLahirTemp2, 0, byteTempatLahir2, 0,
                                    byteTempatLahirTemp2.Length);
            }
            else
            {
                strTempatLahir1 = strTempatLahir;

                byte[] byteTempatLahirTemp1 = Encoding.ASCII.GetBytes(strTempatLahir1);
                Buffer.BlockCopy(byteTempatLahirTemp1, 0, byteTempatLahir1, 0,
                                    byteTempatLahirTemp1.Length);
            }

            swLog.WriteLine("Update Binary Tempat Lahir: " + strTempatLahir);

            // strNama maximum lenght: 32 bytes
            // Write first part of Tempat Lahir to BLOCK 0x05; Length: 16 bytes
            // Write second part of Tempat Lahir to BLOCK 0x06; Length: 16 bytes

            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x05;     // Block number 0x05
            SendBuff[4] = 0x10;

            // Block Data
            SendBuff[5] = 0x00;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x00;
            SendBuff[8] = 0x00;
            SendBuff[9] = 0x00;
            SendBuff[10] = 0x00;
            SendBuff[11] = 0x00;
            SendBuff[12] = 0x00;
            SendBuff[13] = 0x00;
            SendBuff[14] = 0x00;
            SendBuff[15] = 0x00;
            SendBuff[16] = 0x00;
            SendBuff[17] = 0x00;
            SendBuff[18] = 0x00;
            SendBuff[19] = 0x00;
            SendBuff[20] = 0x00;

            Buffer.BlockCopy(byteTempatLahir1, 0, SendBuff, 5, byteTempatLahir1.Length);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Tempat Lahir 1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Tempat Lahir 1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Tempat Lahir 1.";
                MessageBox.Show("ERROR: Failed to Update Binary Tempat Lahir 1.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Tempat Lahir 1 from Block 0x05
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x05;     // Block number 0x05
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Tempat Lahir 1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strTempatLahir3 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Tempat Lahir 1: " + strTempatLahir3);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Tempat Lahir 1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Tempat Lahir 1.";
                MessageBox.Show("ERROR: Failed to Read Binary Tempat Lahir 1.");
                return 1;
            }
            swLog.Flush();

            /*******
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x04;     // Block Number 0x04
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ******/

// Update Binary Tempat Lahir 2 to Block 0x06
SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x06;     // Block Number 0x06
            SendBuff[4] = 0x10;

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            Buffer.BlockCopy(byteTempatLahir2, 0, SendBuff, 5, byteTempatLahir2.Length);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Tempat Lahir 2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Tempat Lahir 2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Tempat Lahir 2.";
                MessageBox.Show("ERROR: Failed to Update Binary Tempat Lahir 2.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Tempat Lahir 2 from Block 0x06
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x06;     // Block number 0x06
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Tempat Lahir 2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strTempatLahir4 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Tempat Lahir 2: " + strTempatLahir4);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Tempat Lahir 2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Tempat Lahir 2.";
                MessageBox.Show("ERROR: Failed to Read Binary Tempat Lahir 2.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteTempatLahir()

        private int WriteTanggalLahir(string strTanggalLahir, ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            byte[] byteTanggalLahir = Encoding.ASCII.GetBytes(strTanggalLahir);

            swLog.WriteLine("General Authenticate Block 0x08");

            // Write Tanggal Lahir to Block number 0x08

            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
			SendBuff[3] = 0x00;
	        SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x08;     // Block Number 0x08
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x08");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate Block 0x08.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate Block 0x08.";
                MessageBox.Show("ERROR: Failed to authenticate Block 0x08.");
                return 1;
            }
            swLog.Flush();

            swLog.WriteLine("Update Binary Tanggal Lahir to block number 0x08: " + strTanggalLahir);

            // Update Binary to Block number 0x08
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x08;     // Block number 0x08
            SendBuff[4] = 0x10;     //(byte) byteTanggalLahir.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            // Buffer.BlockCopy(byteTanggalLahir, 0, SendBuff, 5, byteTanggalLahir.Length);
            Buffer.BlockCopy(byteTanggalLahir, 0, SendBuff, 5, 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;    // byteTanggalLahir.Length;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Tanggal Lahir");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Tanggal Lahir.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Tanggal Lahir.";
                MessageBox.Show("ERROR: Failed to Update Binary Tanggal Lahir.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Tanggal Lahir from Block 0x08
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x08;     // Block number 0x08
            SendBuff[4] = 0x10;     // (byte)byteTanggalLahir.Length;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Tanggal Lahir");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strTanggalLahir3 = "";
                strTanggalLahir3 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Tanggal Lahir: " + strTanggalLahir3);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Tanggal Lahir.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Tanggal Lahir.";
                MessageBox.Show("ERROR: Failed to Read Binary Tanggal Lahir.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteTanggalLahir()

        private void btnTglHariIni_Click(object sender, EventArgs e)
        {
            txtTanggalDaftar.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void LoadSampleData()
        {
            txtNIKWilayah.Text = "123456";
            txtNIKTgl.Text = "123456";
            txtNIKUrut.Text = "1234";
            txtNama.Text = "Agus Purwoko Tambahan Nama Panja";
            txtTempatLahir.Text = "Jakarta Selatan Tambahan Tempat";
            txtTglLahir.Text = "12/07/1975";
            cbJenisKelamin.Text = "LAKI-LAKI";
            txtAlamat1.Text = "Jalan Kemang 2 Blok B4 Nomor 1";
            txtAlamat2.Text = "Bekasi Barat, Kota Bekasi";
            txtPhone.Text = "+62 812 7817 3278";
            txtEmail.Text = "apurwoko@gmail.com";
            txtTanggalDaftar.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Console.WriteLine("The current UI culture: {0}", CultureInfo.CurrentUICulture.Name);
            //CultureInfo.CurrentUICulture = CultureInfo.CreateSpecificCulture("fr-fr");
            //Console.WriteLine("The current UI culture: {0}", CultureInfo.CurrentUICulture.Name);
            textBox1.Text = (CultureInfo.CurrentUICulture.Name);

            //System.IFormatProvider cultureUS = new System.Globalization.CultureInfo("en-US")
            //System.Globalization.CultureInfo cultureFr = new System.Globalization.CultureInfo("fr-fr");
            //CultureInfo.CurrentUICulture = CultureInfo.CreateSpecificCulture("fr-fr");

            //txtBagi.Text = String.Format("{0:N2}", double.Parse(txtBagi.Text));
            //txtInitSaldo.Text = String.Format("{0:N2}", double.Parse(txtInitSaldo.Text));
            //txtSaldo.Text = String.Format("{0:N2}", double.Parse(txtSaldo.Text));
            //txtTopup.Text = String.Format("{0:N2}", double.Parse(txtTopup.Text));




            // txtTanggalDaftar.Text = DateTime.Now.ToString("dd/MM/yyyy");

            TransNumberBlocks[0] = 0x18;
            TransNumberBlocks[1] = 0x1C;
            TransNumberBlocks[2] = 0x20;
            TransNumberBlocks[3] = 0x24;
            TransNumberBlocks[4] = 0x28;

            for(int i=0; i<5; i++)
            {
                transRecords[i] = new TransRecord();
            }

        }

        private int WriteJenisKelamin(string strJenisKelamin,
                                        ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            byte[] byteJenisKelamin = Encoding.ASCII.GetBytes(strJenisKelamin);

            /****
            swLog.WriteLine("General Authenticate block number 0x09");

            // Write Tanggal Lahir to Block number 0x08

            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x08;     // Block Number 0x08
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ****/

            swLog.WriteLine("Update Binary Jenis Kelamin to block number 0x09: " + strJenisKelamin);

            // Update Binary to Block number 0x09
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x09;     // Block number 0x09
            SendBuff[4] = 0x10;     //(byte) byteJenisKelamin.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            // Buffer.BlockCopy(byteTanggalLahir, 0, SendBuff, 5, byteTanggalLahir.Length);
            Buffer.BlockCopy(byteJenisKelamin, 0, SendBuff, 5, 9);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Jenis Kelamin");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Jenis Kelamin.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Jenis Kelamin.";
                MessageBox.Show("ERROR: Failed to Update Binary Jenis Kelamin.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Jenis Kelamin dan Golongan Darah from Block 0x09
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x09;     // Block number 0x09
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Jenis Kelamin");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strJenisKelamin3 = "";
                strJenisKelamin3 = Encoding.ASCII.GetString(RecvBuff.Take(9).ToArray());
                swLog.WriteLine("Read Binary Jenis Kelamin: " + strJenisKelamin3);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Jenis Kelamin.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Jenis Kelamin.";
                MessageBox.Show("ERROR: Failed to Read Binary Jenis Kelamin.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteJenisKelamin()

        // WriteAlamat1: block 0x0A
        // skip block 0x0B
        // WriteAlamat2: block 0x0C
        // WriteAlamat3: block 0x0D
        // WriteAlamat4: block 0x0E

        private int WriteAlamat1(byte[] byteAlamat1,
                        ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            /***
            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x0A;     // Block Number 0x0A
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ****/

            swLog.WriteLine("Update Binary Alamat1 to block number 0x0A: " +
                Encoding.ASCII.GetString(byteAlamat1.ToArray()));

            // Update Binary to Block number 0x0A
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0A;     // Block number 0x0A
            SendBuff[4] = 0x10;     //(byte) byteAlamat1.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            // Buffer.BlockCopy(byteTanggalLahir, 0, SendBuff, 5, byteTanggalLahir.Length);
            Buffer.BlockCopy(byteAlamat1, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Alamat1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Alamat1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Alamat1.";
                MessageBox.Show("ERROR: Failed to Update Binary Alamat1.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Alamat1 from Block 0x0A
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0A;     // Block number 0x0A
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Alamat1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strAlamat1 = "";
                strAlamat1 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Alamat1: " + strAlamat1);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Alamat1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Alamat1.";
                MessageBox.Show("ERROR: Failed to Read Binary Alamat1.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteAlamat1()

        // WriteAlamat1: block 0x0A
        // skip block 0x0B
        // WriteAlamat2: block 0x0C
        // WriteAlamat3: block 0x0D
        // WriteAlamat4: block 0x0E

        private int WriteAlamat2(byte[] byteAlamat2,
                        ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x0C;     // Block Number 0x0C
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x0C");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate Block 0x0C.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate Block 0x0C.";
                MessageBox.Show("ERROR: Failed to authenticate Block 0x0C.");
                return 1;
            }
            swLog.Flush();

            swLog.WriteLine("Update Binary Alamat2 to block number 0x0C: " +
                Encoding.ASCII.GetString(byteAlamat2.ToArray()));

            // Update Binary to Block number 0x0A
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0C;     // Block number 0x0C
            SendBuff[4] = 0x10;     //(byte) byteAlamat2.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            // Buffer.BlockCopy(byteTanggalLahir, 0, SendBuff, 5, byteTanggalLahir.Length);
            Buffer.BlockCopy(byteAlamat2, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Alamat2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Alamat2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Alamat2.";
                MessageBox.Show("ERROR: Failed to Update Binary Alamat2.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Alamat2 from Block 0x0C
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0C;     // Block number 0x0C
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Alamat2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strAlamat2 = "";
                strAlamat2 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Alamat2: " + strAlamat2);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Alamat2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Alamat2.";
                MessageBox.Show("ERROR: Failed to Read Binary Alamat2.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteAlamat2()

        private int WriteAlamat3(byte[] byteAlamat3,
                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            /***
            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x0C;     // Block Number 0x0C
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ***/

            swLog.WriteLine("Update Binary Alamat3 to block number 0x0D: " +
                Encoding.ASCII.GetString(byteAlamat3.ToArray()));

            // Update Binary to Block number 0x0A
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0D;     // Block number 0x0D
            SendBuff[4] = 0x10;     //(byte) byteAlamat3.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteAlamat3, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Alamat3");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Alamat3.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Alamat3.";
                MessageBox.Show("ERROR: Failed to Update Binary Alamat3.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Alamat3 from Block 0x0D
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0D;     // Block number 0x0D
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Alamat3");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strAlamat3 = "";
                strAlamat3 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Alamat3: " + strAlamat3);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Alamat3.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Alamat3.";
                MessageBox.Show("ERROR: Failed to Read Binary Alamat3.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteAlamat3()

        private int WriteAlamat4(byte[] byteAlamat4,
                        ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            /***
            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x0C;     // Block Number 0x0C
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ***/

            swLog.WriteLine("Update Binary Alamat4 to block number 0x0E: " +
                Encoding.ASCII.GetString(byteAlamat4.ToArray()));

            // Update Binary to Block number 0x0A
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0E;     // Block number 0x0E
            SendBuff[4] = 0x10;     //(byte) byteAlamat4.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteAlamat4, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Alamat4");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Alamat4.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Alamat4.";
                MessageBox.Show("ERROR: Failed to Update Binary Alamat4.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Alamat4 from Block 0x0E
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0E;     // Block number 0x0E
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Alamat4");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strAlamat4 = "";
                strAlamat4 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Alamat4: " + strAlamat4);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Alamat4.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Alamat4.";
                MessageBox.Show("ERROR: Failed to Read Binary Alamat4.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteAlamat4()

        private int WriteAlamat(string strAlamat1, string strAlamat2,
                                ModWinsCard.SCARD_IO_REQUEST request)
        {
            // int status;
            // int sendLength;
            // int outBytes;
            // byte[] result = new byte[2];

            byte[] byteAlamat = new byte[64];

            Array.Clear(byteAlamat, 0, 64);

            byte[] byteAlamat1 = new byte[16];
            byte[] byteAlamat2 = new byte[16];
            byte[] byteAlamat3 = new byte[16];
            byte[] byteAlamat4 = new byte[16];

            Array.Clear(byteAlamat1, 0, 16);
            Array.Clear(byteAlamat2, 0, 16);
            Array.Clear(byteAlamat3, 0, 16);
            Array.Clear(byteAlamat4, 0, 16);

            if ( strAlamat1.Length > 16 )
            {
                byte[] byteAlamatTemp1 = Encoding.ASCII.GetBytes(strAlamat1);
                Buffer.BlockCopy(byteAlamatTemp1, 0, byteAlamat1, 0, 16);
                Buffer.BlockCopy(byteAlamatTemp1, 16, byteAlamat2, 0, 
                                    byteAlamatTemp1.Length - 16);
            }
            else
            {
                byte[] byteAlamatTemp1 = Encoding.ASCII.GetBytes(strAlamat1);
                Buffer.BlockCopy(byteAlamatTemp1, 0, byteAlamat1, 0,
                                    byteAlamatTemp1.Length);
            }

            if (strAlamat2.Length > 16)
            {
                byte[] byteAlamatTemp2 = Encoding.ASCII.GetBytes(strAlamat2);
                Buffer.BlockCopy(byteAlamatTemp2, 0, byteAlamat3, 0, 16);
                Buffer.BlockCopy(byteAlamatTemp2, 16, byteAlamat4, 0,
                                    byteAlamatTemp2.Length - 16);
            }
            else
            {
                byte[] byteAlamatTemp2 = Encoding.ASCII.GetBytes(strAlamat2);
                Buffer.BlockCopy(byteAlamatTemp2, 0, byteAlamat3, 0,
                                    byteAlamatTemp2.Length);
            }

            WriteAlamat1(byteAlamat1, request);     // block 0x0A
            WriteAlamat2(byteAlamat2, request);     // block 0x0C
            WriteAlamat3(byteAlamat3, request);     // block 0x0D
            WriteAlamat4(byteAlamat4, request);     // block 0x0E
           
            return 0;
        } // WriteAlamat()

        // block 0x10; bytePhone1
        private int WritePhone1(byte[] bytePhone1,
                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // General authenticate - block 0x10
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x10;     // Block Number 0x10
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x10");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x10.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x10.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x10.");
                return 1;
            }
            swLog.Flush();

            swLog.WriteLine("Update Binary Phone1 to block number 0x10: " +
                Encoding.ASCII.GetString(bytePhone1.ToArray()));

            // Update Binary to Block number 0x10
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x10;     // Block number 0x10
            SendBuff[4] = 0x10;     //(byte) bytePhone1.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(bytePhone1, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Phone1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Phone1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Phone1.";
                MessageBox.Show("ERROR: Failed to Update Binary Phone1.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Phone1 from Block 0x10
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x10;     // Block number 0x10
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Phone1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strPhone1 = "";
                strPhone1 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Phone1: " + strPhone1);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Phone1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Phone1.";
                MessageBox.Show("ERROR: Failed to Read Binary Phone1.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WritePhone1()

        // block 0x11; bytePhone2
        private int WritePhone2(byte[] bytePhone2,
                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            /****
            // General authenticate - block 0x10
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x10;     // Block Number 0x10
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ***/

            swLog.WriteLine("Update Binary Phone2 to block number 0x11: " +
                Encoding.ASCII.GetString(bytePhone2.ToArray()));

            // Update Binary to Block number 0x11
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x11;     // Block number 0x11
            SendBuff[4] = 0x10;     //(byte) bytePhone2.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(bytePhone2, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Phone2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Phone2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Phone2.";
                MessageBox.Show("ERROR: Failed to Update Binary Phone2.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Phone2 from Block 0x11
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x11;     // Block number 0x11
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Phone2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strPhone2 = "";
                strPhone2 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Phone2: " + strPhone2);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Phone2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Phone2.";
                MessageBox.Show("ERROR: Failed to Read Binary Phone2.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WritePhone2()

        private int WritePhone(string strPhone, ModWinsCard.SCARD_IO_REQUEST request)
        {
            byte[] bytePhone = new byte[32];

            Array.Clear(bytePhone, 0, 32);

            byte[] bytePhoneTemp = Encoding.ASCII.GetBytes(strPhone);
            Buffer.BlockCopy(bytePhoneTemp, 0, bytePhone, 0, bytePhoneTemp.Length);

            byte[] bytePhone1 = new byte[16];
            byte[] bytePhone2 = new byte[16];

            Buffer.BlockCopy(bytePhone, 0, bytePhone1, 0, 16);
            Buffer.BlockCopy(bytePhone, 16, bytePhone2, 0, 16);

            // Block 0x10 and block 0x11; Phone number; 32 bytes
            WritePhone1(bytePhone1, request);     // block 0x10
            WritePhone2(bytePhone2, request);     // block 0x11

            return 0;
        } // WritePhone()

        // block 0x12; byteEmail1
        private int WriteEmail1(byte[] byteEmail1,
                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            /****
            // General authenticate - block 0x10
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x10;     // Block Number 0x10
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ***/

            swLog.WriteLine("Update Binary Email1 to block number 0x12: " +
                Encoding.ASCII.GetString(byteEmail1.ToArray()));

            // Update Binary to Block number 0x12
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x12;     // Block number 0x12
            SendBuff[4] = 0x10;     //(byte) byteEmail1.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteEmail1, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Email1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Email1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Email1.";
                MessageBox.Show("ERROR: Failed to Update Binary Email1.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Email1 from Block 0x12
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x12;     // Block number 0x12
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Email1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strEmail1 = "";
                strEmail1 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Email1: " + strEmail1);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Email1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Email1.";
                MessageBox.Show("ERROR: Failed to Read Binary Email1.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteEmail1()

        // block 0x14; byteEmail2
        private int WriteEmail2(byte[] byteEmail2,
                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // General authenticate - block 0x14
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x14;     // Block Number 0x14
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x14");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x14.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x14.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x14.");
                return 1;
            }
            swLog.Flush();

            swLog.WriteLine("Update Binary Email2 to block number 0x14: " +
                Encoding.ASCII.GetString(byteEmail2.ToArray()));

            // Update Binary to Block number 0x14
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x14;     // Block number 0x14
            SendBuff[4] = 0x10;     //(byte) byteEmail2.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteEmail2, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Email2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Email2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Email2.";
                MessageBox.Show("ERROR: Failed to Update Binary Email2.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Email2 from Block 0x14
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x14;     // Block number 0x14
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Email2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strEmail2 = "";
                strEmail2 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Email2: " + strEmail2);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Email2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Email2.";
                MessageBox.Show("ERROR: Failed to Read Binary Email2.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteEmail2()

        // Block 0x12 and block 0x14; Email address; skip block 0x13; 32 bytes
        // Authenticate block 0x14
        private int WriteEmail(string strEmail, ModWinsCard.SCARD_IO_REQUEST request)
        {
            byte[] byteEmail = new byte[32];

            Array.Clear(byteEmail, 0, 32);

            byte[] byteEmailTemp = Encoding.ASCII.GetBytes(strEmail);
            Buffer.BlockCopy(byteEmailTemp, 0, byteEmail, 0, byteEmailTemp.Length);

            byte[] byteEmail1 = new byte[16];
            byte[] byteEmail2 = new byte[16];

            Buffer.BlockCopy(byteEmail, 0, byteEmail1, 0, 16);
            Buffer.BlockCopy(byteEmail, 16, byteEmail2, 0, 16);

            // Block 0x12 and block 0x14; Email address; 32 bytes
            WriteEmail1(byteEmail1, request);     // block 0x12
            WriteEmail2(byteEmail2, request);     // block 0x14

            return 0;
        } // WriteEmail()

        private void deleteRowsDGV()
        {
            do
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    try
                    {
                        dataGridView1.Rows.Remove(row);
                    }
                    catch (Exception) { }
                }
            } while (dataGridView1.Rows.Count > 1);
        }
        private void BersihkanIsian()
        {
            txtNIKWilayah.Text = "";
            txtNIKTgl.Text = "";
            txtNIKUrut.Text = "";
            txtNama.Text = "";
            txtTempatLahir.Text = "";
            txtTglLahir.Text = "";
            txtAlamat1.Text = "";
            txtAlamat2.Text = "";
            txtPhone.Text = "";
            txtEmail.Text = "";
            txtTanggalDaftar.Text = "";
            txtInitSaldo.Text = "";
            txtSaldo.Text = "";
            txtTopup.Text = "";
            txtBagi.Text = "";

            deleteRowsDGV();
        }

        private void btnBersihkan_Click(object sender, EventArgs e)
        {
            BersihkanIsian();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            swLog.Flush();
            swLog.Close();
        }

        private int ReadNIK(ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // swLog.WriteLine("Read Binary NIK");
            // Read Binary NIK
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x01; // Block 0x01; NIK
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary NIK");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strNIK2 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary NIK " + strNIK2);
                // MessageBox.Show("NIK: " + strNIK2);
                txtNIKWilayah.Text = strNIK2.Substring(0, 6);
                txtNIKTgl.Text = strNIK2.Substring(6, 6);
                txtNIKUrut.Text = strNIK2.Substring(12, 4);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary NIK.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary NIK.";
                MessageBox.Show("ERROR: Failed to Read Binary NIK.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadNIK()        

        private int ReadNama(ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            string strNama1 = "";
            string strNama2 = "";

            /***
            if (strNama.Length > 16)
            {
                strNama1 = strNama.Substring(0, 16);
                strNama2 = strNama.Substring(16);

            }
            else
            {
                strNama1 = strNama;
            }

            byte[] byteNama1 = Encoding.ASCII.GetBytes(strNama1);
            byte[] byteNama2 = Encoding.ASCII.GetBytes(strNama2);

            swLog.WriteLine("Update Binary Nama: " + strNama);

            // strNama maximum lenght: 32 bytes
            // Write first part of Nama to BLOCK 0x02; Length: 16 bytes
            // Write second part of Nama to BLOCK 0x04; Length: 16 bytes

            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x02; // Block 0x02
            SendBuff[4] = 0x10;

            // Block Data
            SendBuff[5] = 0x00;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x00;
            SendBuff[8] = 0x00;
            SendBuff[9] = 0x00;
            SendBuff[10] = 0x00;
            SendBuff[11] = 0x00;
            SendBuff[12] = 0x00;
            SendBuff[13] = 0x00;
            SendBuff[14] = 0x00;
            SendBuff[15] = 0x00;
            SendBuff[16] = 0x00;
            SendBuff[17] = 0x00;
            SendBuff[18] = 0x00;
            SendBuff[19] = 0x00;
            SendBuff[20] = 0x00;

            Buffer.BlockCopy(byteNama1, 0, SendBuff, 5, byteNama1.Length);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Nama1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Nama1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Nama1.";
                MessageBox.Show("ERROR: Failed to Update Binary Nama1.");
                return 1;
            }
            swLog.Flush();
            ***/

            // Read Binary Nama 1 from Block 0x02
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x02; // // Block 0x02
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Nama1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strNama3 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Nama 1: " + strNama3);
                strNama1 = strNama3;
                // MessageBox.Show("Read Binary Nama 1: " + strNama3);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Nama1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Nama1.";
                MessageBox.Show("ERROR: Failed to Read Binary Nama1.");
                return 1;
            }
            swLog.Flush();

            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x04;     // Block Number 0x04
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x04");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x04.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x04.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x04.");
                return 1;
            }
            swLog.Flush();

            /***
            // Update Binary Nama 2 to Block 0x04
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x04;     // Block Number 0x04
            SendBuff[4] = 0x10;

            // Block Data
            SendBuff[5] = 0x00;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x00;
            SendBuff[8] = 0x00;
            SendBuff[9] = 0x00;
            SendBuff[10] = 0x00;
            SendBuff[11] = 0x00;
            SendBuff[12] = 0x00;
            SendBuff[13] = 0x00;
            SendBuff[14] = 0x00;
            SendBuff[15] = 0x00;
            SendBuff[16] = 0x00;
            SendBuff[17] = 0x00;
            SendBuff[18] = 0x00;
            SendBuff[19] = 0x00;
            SendBuff[20] = 0x00;

            // MessageBox.Show("byteNama2.Length: " + byteNama2.Length.ToString());
            Buffer.BlockCopy(byteNama2, 0, SendBuff, 5, byteNama2.Length);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Nama2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Nama2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Nama2.";
                MessageBox.Show("ERROR: Failed to Update Binary Nama2.");
                return 1;
            }
            swLog.Flush();
            ***/

            // Read Binary Nama 2 from Block 0x04
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x04;
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Nama 2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strNama4 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Nama 2: " + strNama4);
                strNama2 = strNama4;
                // MessageBox.Show("Read Binary Nama 2: " + strNama4);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Nama2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Nama2.";
                MessageBox.Show("ERROR: Failed to Read Binary Nama2.");
                return 1;
            }
            swLog.Flush();

            string strNama = strNama1 + strNama2;
            txtNama.Text = strNama;

            return 0;
        } // ReadNama()

        private int ReadTempatLahir(ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            string strTempatLahir1 = "";
            string strTempatLahir2 = "";

            /****
            if (strTempatLahir.Length > 16)
            {
                strTempatLahir1 = strTempatLahir.Substring(0, 16);
                strTempatLahir2 = strTempatLahir.Substring(16);

            }
            else
            {
                strTempatLahir1 = strTempatLahir;
            }

            byte[] byteTempatLahir1 = Encoding.ASCII.GetBytes(strTempatLahir1);
            byte[] byteTempatLahir2 = Encoding.ASCII.GetBytes(strTempatLahir2);

            swLog.WriteLine("Update Binary Tempat Lahir: " + strTempatLahir);

            // strNama maximum lenght: 32 bytes
            // Write first part of Tempat Lahir to BLOCK 0x05; Length: 16 bytes
            // Write second part of Tempat Lahir to BLOCK 0x06; Length: 16 bytes

            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x05;     // Block number 0x05
            SendBuff[4] = 0x10;

            // Block Data
            SendBuff[5] = 0x00;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x00;
            SendBuff[8] = 0x00;
            SendBuff[9] = 0x00;
            SendBuff[10] = 0x00;
            SendBuff[11] = 0x00;
            SendBuff[12] = 0x00;
            SendBuff[13] = 0x00;
            SendBuff[14] = 0x00;
            SendBuff[15] = 0x00;
            SendBuff[16] = 0x00;
            SendBuff[17] = 0x00;
            SendBuff[18] = 0x00;
            SendBuff[19] = 0x00;
            SendBuff[20] = 0x00;

            Buffer.BlockCopy(byteTempatLahir1, 0, SendBuff, 5, byteTempatLahir1.Length);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Tempat Lahir 1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Tempat Lahir 1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Tempat Lahir 1.";
                MessageBox.Show("ERROR: Failed to Update Binary Tempat Lahir 1.");
                return 1;
            }
            swLog.Flush();
            ***/

            // Read Binary Nama 1 from Block 0x05
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x05;     // Block number 0x05
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Tempat Lahir 1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strTempatLahir3 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                strTempatLahir1 = strTempatLahir3;
                swLog.WriteLine("Read Binary Tempat Lahir 1: " + strTempatLahir3);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Tempat Lahir 1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Tempat Lahir 1.";
                MessageBox.Show("ERROR: Failed to Read Binary Tempat Lahir 1.");
                return 1;
            }
            swLog.Flush();

            /*******
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x04;     // Block Number 0x04
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ******/

            /***
            // Update Binary Tempat Lahir 2 to Block 0x06
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x06;     // Block Number 0x06
            SendBuff[4] = 0x10;

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            Buffer.BlockCopy(byteTempatLahir2, 0, SendBuff, 5, byteTempatLahir2.Length);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Tempat Lahir 2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Tempat Lahir 2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Tempat Lahir 2.";
                MessageBox.Show("ERROR: Failed to Update Binary Tempat Lahir 2.");
                return 1;
            }
            swLog.Flush();
            ***/

            // Read Binary Tempat Lahir 2 from Block 0x06
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x06;     // Block number 0x06
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Tempat Lahir 2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strTempatLahir4 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                strTempatLahir2 = strTempatLahir4;
                swLog.WriteLine("Read Binary Tempat Lahir 2: " + strTempatLahir4);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Tempat Lahir 2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Tempat Lahir 2.";
                MessageBox.Show("ERROR: Failed to Read Binary Tempat Lahir 2.");
                return 1;
            }
            swLog.Flush();

            string strTempatLahir = strTempatLahir1 + strTempatLahir2;
            txtTempatLahir.Text = strTempatLahir;

            return 0;
        } // ReadTempatLahir()

        private int ReadTanggalLahir(ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // byte[] byteTanggalLahir = Encoding.ASCII.GetBytes(strTanggalLahir);

            swLog.WriteLine("General Authenticate Block 0x08");

            // Write Tanggal Lahir to Block number 0x08

            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x08;     // Block Number 0x08
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x08");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate Block 0x08.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate Block 0x08.";
                MessageBox.Show("ERROR: Failed to authenticate Block 0x08.");
                return 1;
            }
            swLog.Flush();

            /***
            swLog.WriteLine("Update Binary Tanggal Lahir to block number 0x08: " + strTanggalLahir);

            // Update Binary to Block number 0x08
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x08;     // Block number 0x08
            SendBuff[4] = 0x10;     //(byte) byteTanggalLahir.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            // Buffer.BlockCopy(byteTanggalLahir, 0, SendBuff, 5, byteTanggalLahir.Length);
            Buffer.BlockCopy(byteTanggalLahir, 0, SendBuff, 5, 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;    // byteTanggalLahir.Length;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Tanggal Lahir");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Tanggal Lahir.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Tanggal Lahir.";
                MessageBox.Show("ERROR: Failed to Update Binary Tanggal Lahir.");
                return 1;
            }
            swLog.Flush();
            ***/

            // Read Binary Tanggal Lahir from Block 0x08
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x08;     // Block number 0x08
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            string strTanggalLahir = "";
            swLog.WriteLine("Read Binary Tanggal Lahir");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strTanggalLahir3 = "";
                strTanggalLahir3 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                strTanggalLahir = strTanggalLahir3;
                swLog.WriteLine("Read Binary Tanggal Lahir: " + strTanggalLahir3);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Tanggal Lahir.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Tanggal Lahir.";
                MessageBox.Show("ERROR: Failed to Read Binary Tanggal Lahir.");
                return 1;
            }
            swLog.Flush();

            txtTglLahir.Text = strTanggalLahir;

            return 0;
        } // ReadTanggalLahir()

        private int ReadJenisKelamin(ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // byte[] byteJenisKelamin = Encoding.ASCII.GetBytes(strJenisKelamin);

            /****
            swLog.WriteLine("General Authenticate block number 0x09");

            // Write Tanggal Lahir to Block number 0x08

            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x08;     // Block Number 0x08
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ****/

            /***
            swLog.WriteLine("Update Binary Jenis Kelamin to block number 0x09: " + strJenisKelamin);

            // Update Binary to Block number 0x09
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x09;     // Block number 0x09
            SendBuff[4] = 0x10;     //(byte) byteJenisKelamin.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            // Buffer.BlockCopy(byteTanggalLahir, 0, SendBuff, 5, byteTanggalLahir.Length);
            Buffer.BlockCopy(byteJenisKelamin, 0, SendBuff, 5, 9);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Jenis Kelamin");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Jenis Kelamin.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Jenis Kelamin.";
                MessageBox.Show("ERROR: Failed to Update Binary Jenis Kelamin.");
                return 1;
            }
            swLog.Flush();
            ***/

            // Read Binary Jenis Kelamin dan Golongan Darah from Block 0x09
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x09;     // Block number 0x09
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            string strJenisKelamin = "";
            swLog.WriteLine("Read Binary Jenis Kelamin");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strJenisKelamin3 = "";
                strJenisKelamin3 = Encoding.ASCII.GetString(RecvBuff.Take(9).ToArray());
                strJenisKelamin = strJenisKelamin3;
                swLog.WriteLine("Read Binary Jenis Kelamin: " + strJenisKelamin3);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Jenis Kelamin.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Jenis Kelamin.";
                MessageBox.Show("ERROR: Failed to Read Binary Jenis Kelamin.");
                return 1;
            }
            swLog.Flush();

            cbJenisKelamin.Text = strJenisKelamin;

            return 0;
        } // ReadJenisKelamin()

        // ReadAlamat1: block 0x0A
        // skip block 0x0B
        // ReadAlamat2: block 0x0C
        // ReadAlamat3: block 0x0D
        // ReadAlamat4: block 0x0E

        private int ReadAlamat1(ref string strAlamat1, ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            /***
            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x0A;     // Block Number 0x0A
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ****/

            /****
            swLog.WriteLine("Update Binary Alamat1 to block number 0x0A: " +
                Encoding.ASCII.GetString(byteAlamat1.ToArray()));

            // Update Binary to Block number 0x0A
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0A;     // Block number 0x0A
            SendBuff[4] = 0x10;     //(byte) byteAlamat1.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            // Buffer.BlockCopy(byteTanggalLahir, 0, SendBuff, 5, byteTanggalLahir.Length);
            Buffer.BlockCopy(byteAlamat1, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Alamat1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Alamat1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Alamat1.";
                MessageBox.Show("ERROR: Failed to Update Binary Alamat1.");
                return 1;
            }
            swLog.Flush();
            ***/

            // Read Binary Alamat1 from Block 0x0A
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0A;     // Block number 0x0A
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // string strAlamat1 = "";
            swLog.WriteLine("Read Binary Alamat1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                strAlamat1 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Alamat1: " + strAlamat1);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Alamat1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Alamat1.";
                MessageBox.Show("ERROR: Failed to Read Binary Alamat1.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadAlamat1()

        // WriteAlamat1: block 0x0A
        // skip block 0x0B
        // WriteAlamat2: block 0x0C
        // WriteAlamat3: block 0x0D
        // WriteAlamat4: block 0x0E

        private int ReadAlamat2(ref string strAlamat2,
                        ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x0C;     // Block Number 0x0C
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x0C");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate Block 0x0C.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate Block 0x0C.";
                MessageBox.Show("ERROR: Failed to authenticate Block 0x0C.");
                return 1;
            }
            swLog.Flush();

            /****
            swLog.WriteLine("Update Binary Alamat2 to block number 0x0C: " +
                Encoding.ASCII.GetString(byteAlamat2.ToArray()));

            // Update Binary to Block number 0x0A
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0C;     // Block number 0x0C
            SendBuff[4] = 0x10;     //(byte) byteAlamat2.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            // Buffer.BlockCopy(byteTanggalLahir, 0, SendBuff, 5, byteTanggalLahir.Length);
            Buffer.BlockCopy(byteAlamat2, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Alamat2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Alamat2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Alamat2.";
                MessageBox.Show("ERROR: Failed to Update Binary Alamat2.");
                return 1;
            }
            swLog.Flush();
            ****/

            // Read Binary Alamat2 from Block 0x0C
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0C;     // Block number 0x0C
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Alamat2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                strAlamat2 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Alamat2: " + strAlamat2);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Alamat2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Alamat2.";
                MessageBox.Show("ERROR: Failed to Read Binary Alamat2.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadAlamat2()

        private int ReadAlamat3(ref string strAlamat3,
                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            /***
            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x0C;     // Block Number 0x0C
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ***/

            /***
            swLog.WriteLine("Update Binary Alamat3 to block number 0x0D: " +
                Encoding.ASCII.GetString(byteAlamat3.ToArray()));

            // Update Binary to Block number 0x0A
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0D;     // Block number 0x0D
            SendBuff[4] = 0x10;     //(byte) byteAlamat3.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteAlamat3, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Alamat3");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Alamat3.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Alamat3.";
                MessageBox.Show("ERROR: Failed to Update Binary Alamat3.");
                return 1;
            }
            swLog.Flush();
            ***/

            // Read Binary Alamat3 from Block 0x0D
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0D;     // Block number 0x0D
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Alamat3");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                strAlamat3 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Alamat3: " + strAlamat3);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Alamat3.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Alamat3.";
                MessageBox.Show("ERROR: Failed to Read Binary Alamat3.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteAlamat3()

        private int ReadAlamat4(ref string strAlamat4,
                        ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            /***
            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x0C;     // Block Number 0x0C
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ***/

            /***
            swLog.WriteLine("Update Binary Alamat4 to block number 0x0E: " +
                Encoding.ASCII.GetString(byteAlamat4.ToArray()));

            // Update Binary to Block number 0x0A
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0E;     // Block number 0x0E
            SendBuff[4] = 0x10;     //(byte) byteAlamat4.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteAlamat4, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Alamat4");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Alamat4.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Alamat4.";
                MessageBox.Show("ERROR: Failed to Update Binary Alamat4.");
                return 1;
            }
            swLog.Flush();
            ***/

            // Read Binary Alamat4 from Block 0x0E
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x0E;     // Block number 0x0E
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Alamat4");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                strAlamat4 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Alamat4: " + strAlamat4);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Alamat4.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Alamat4.";
                MessageBox.Show("ERROR: Failed to Read Binary Alamat4.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadAlamat4()

        private int ReadAlamat(ModWinsCard.SCARD_IO_REQUEST request)
        {
            // int status;
            // int sendLength;
            // int outBytes;
            // byte[] result = new byte[2];

            /***
            byte[] byteAlamat = new byte[64];

            Array.Clear(byteAlamat, 0, 64);

            byte[] byteAlamatTemp = Encoding.ASCII.GetBytes(strAlamat);
            Buffer.BlockCopy(byteAlamatTemp, 0, byteAlamat, 0, byteAlamatTemp.Length);

            byte[] byteAlamat1 = new byte[16];
            byte[] byteAlamat2 = new byte[16];
            byte[] byteAlamat3 = new byte[16];
            byte[] byteAlamat4 = new byte[16];

            Buffer.BlockCopy(byteAlamat, 0, byteAlamat1, 0, 16);
            Buffer.BlockCopy(byteAlamat, 16, byteAlamat2, 0, 16);
            Buffer.BlockCopy(byteAlamat, 32, byteAlamat3, 0, 16);
            Buffer.BlockCopy(byteAlamat, 48, byteAlamat4, 0, 16);
            ***/

            string strAlamat1 = "";
            string strAlamat2 = "";
            string strAlamat3 = "";
            string strAlamat4 = "";

            ReadAlamat1(ref strAlamat1, request);     // block 0x0A
            ReadAlamat2(ref strAlamat2, request);     // block 0x0C
            ReadAlamat3(ref strAlamat3, request);     // block 0x0D
            ReadAlamat4(ref strAlamat4, request);     // block 0x0E

            strAlamat1 = strAlamat1 + strAlamat2;
            strAlamat3 = strAlamat3 + strAlamat4;

            txtAlamat1.Text = strAlamat1;
            txtAlamat2.Text = strAlamat3;

            return 0;
        } // ReadAlamat()

        // block 0x10; strPhone1
        private int ReadPhone1(ref string strPhone1,
                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // General authenticate - block 0x10
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x10;     // Block Number 0x10
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x10");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x10.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x10.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x10.");
                return 1;
            }
            swLog.Flush();

            /****
            swLog.WriteLine("Update Binary Phone1 to block number 0x10: " +
                Encoding.ASCII.GetString(bytePhone1.ToArray()));

            // Update Binary to Block number 0x10
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x10;     // Block number 0x10
            SendBuff[4] = 0x10;     //(byte) bytePhone1.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(bytePhone1, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Phone1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Phone1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Phone1.";
                MessageBox.Show("ERROR: Failed to Update Binary Phone1.");
                return 1;
            }
            swLog.Flush();
            ****/

            // Read Binary Phone1 from Block 0x10
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x10;     // Block number 0x10
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Phone1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                strPhone1 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Phone1: " + strPhone1);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Phone1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Phone1.";
                MessageBox.Show("ERROR: Failed to Read Binary Phone1.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadPhone1()

        // block 0x11; strPhone2
        private int ReadPhone2(ref string strPhone2,
                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            /****
            // General authenticate - block 0x10
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x10;     // Block Number 0x10
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ***/

            /****
            swLog.WriteLine("Update Binary Phone2 to block number 0x11: " +
                Encoding.ASCII.GetString(bytePhone2.ToArray()));

            // Update Binary to Block number 0x11
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x11;     // Block number 0x11
            SendBuff[4] = 0x10;     //(byte) bytePhone2.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(bytePhone2, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Phone2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Phone2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Phone2.";
                MessageBox.Show("ERROR: Failed to Update Binary Phone2.");
                return 1;
            }
            swLog.Flush();
            ****/

            // Read Binary Phone2 from Block 0x11
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x11;     // Block number 0x11
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Phone2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                strPhone2 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Phone2: " + strPhone2);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Phone2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Phone2.";
                MessageBox.Show("ERROR: Failed to Read Binary Phone2.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadPhone2()

        private int ReadPhone(ModWinsCard.SCARD_IO_REQUEST request)
        {
            /****
            byte[] bytePhone = new byte[32];

            Array.Clear(bytePhone, 0, 32);

            byte[] bytePhoneTemp = Encoding.ASCII.GetBytes(strPhone);
            Buffer.BlockCopy(bytePhoneTemp, 0, bytePhone, 0, bytePhoneTemp.Length);

            byte[] bytePhone1 = new byte[16];
            byte[] bytePhone2 = new byte[16];

            Buffer.BlockCopy(bytePhone, 0, bytePhone1, 0, 16);
            Buffer.BlockCopy(bytePhone, 16, bytePhone2, 0, 16);
            ****/

            string strPhone1 = "";
            string strPhone2 = "";

            // Block 0x10 and block 0x11; Phone number; 32 bytes
            ReadPhone1(ref strPhone1, request);     // block 0x10
            ReadPhone2(ref strPhone2, request);     // block 0x11

            strPhone1 = strPhone1 + strPhone2;
            txtPhone.Text = strPhone1;

            return 0;
        } // ReadPhone()

        // block 0x12; byteEmail1
        private int ReadEmail1(ref string strEmail1,
                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            /****
            // General authenticate - block 0x10
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x10;     // Block Number 0x10
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ***/

            /****
            swLog.WriteLine("Update Binary Email1 to block number 0x12: " +
                Encoding.ASCII.GetString(byteEmail1.ToArray()));

            // Update Binary to Block number 0x12
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x12;     // Block number 0x12
            SendBuff[4] = 0x10;     //(byte) byteEmail1.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteEmail1, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Email1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Email1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Email1.";
                MessageBox.Show("ERROR: Failed to Update Binary Email1.");
                return 1;
            }
            swLog.Flush();
            ****/

            // Read Binary Email1 from Block 0x12
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x12;     // Block number 0x12
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Email1");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                strEmail1 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Email1: " + strEmail1);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Email1.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Email1.";
                MessageBox.Show("ERROR: Failed to Read Binary Email1.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadEmail1()

        // block 0x14; byteEmail2
        private int ReadEmail2(ref string strEmail2,
                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // General authenticate - block 0x14
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x14;     // Block Number 0x14
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x14");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x14.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x14.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x14.");
                return 1;
            }
            swLog.Flush();

            /****
            swLog.WriteLine("Update Binary Email2 to block number 0x14: " +
                Encoding.ASCII.GetString(byteEmail2.ToArray()));

            // Update Binary to Block number 0x14
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x14;     // Block number 0x14
            SendBuff[4] = 0x10;     //(byte) byteEmail2.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteEmail2, 0, SendBuff, 5, 16);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Email2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Email2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Email2.";
                MessageBox.Show("ERROR: Failed to Update Binary Email2.");
                return 1;
            }
            swLog.Flush();
            ****/

            // Read Binary Email2 from Block 0x14
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x14;     // Block number 0x14
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Email2");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                strEmail2 = Encoding.ASCII.GetString(RecvBuff.Take(16).ToArray());
                swLog.WriteLine("Read Binary Email2: " + strEmail2);

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Email2.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Email2.";
                MessageBox.Show("ERROR: Failed to Read Binary Email2.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadEmail2()

        // Block 0x12 and block 0x14; Email address; skip block 0x13; 32 bytes
        // Authenticate block 0x14
        private int ReadEmail(ModWinsCard.SCARD_IO_REQUEST request)
        {
            /****
            byte[] byteEmail = new byte[32];

            Array.Clear(byteEmail, 0, 32);

            byte[] byteEmailTemp = Encoding.ASCII.GetBytes(strEmail);
            Buffer.BlockCopy(byteEmailTemp, 0, byteEmail, 0, byteEmailTemp.Length);

            byte[] byteEmail1 = new byte[16];
            byte[] byteEmail2 = new byte[16];

            Buffer.BlockCopy(byteEmail, 0, byteEmail1, 0, 16);
            Buffer.BlockCopy(byteEmail, 16, byteEmail2, 0, 16);
            ****/

            string strEmail1 = "";
            string strEmail2 = "";

            // Block 0x12 and block 0x14; Email address; 32 bytes
            ReadEmail1(ref strEmail1, request);     // block 0x12
            ReadEmail2(ref strEmail2, request);     // block 0x14

            strEmail1 = strEmail1 + strEmail2;
            txtEmail.Text = strEmail1;

            return 0;
        } // ReadEmail()

        // block 0x15; Tanggal Daftar
        private int ReadTanggalDaftar(ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // byte[] byteTanggalDaftar = Encoding.ASCII.GetBytes(strTanggalDaftar);

            /***
            swLog.WriteLine("General Authenticate block number 0x14");

            // Write Tanggal Daftar to Block number 0x14

            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x14;     // Block Number 0x14
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ***/

            /****
            swLog.WriteLine("Update Binary Tanggal Daftar to block number 0x15: " + strTanggalDaftar);

            // Update Binary to Block number 0x08
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x15;     // Block number 0x15
            SendBuff[4] = 0x10;     //(byte) byteTanggalDaftar.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteTanggalDaftar, 0, SendBuff, 5, 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;    // byteTanggalDaftar.Length;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Tanggal Daftar");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Tanggal Daftar.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Tanggal Daftar.";
                MessageBox.Show("ERROR: Failed to Update Binary Tanggal Daftar.");
                return 1;
            }
            swLog.Flush();
            ****/

            // Read Binary Tanggal Daftar from Block 0x15
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x15;     // Block number 0x15
            SendBuff[4] = 0x10;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            string strTanggalDaftar1 = "";
            swLog.WriteLine("Read Binary Tanggal Daftar");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                strTanggalDaftar1 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Tanggal Daftar: " + strTanggalDaftar1);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Tanggal Daftar.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Tanggal Daftar.";
                MessageBox.Show("ERROR: Failed to Read Binary Tanggal Daftar.");
                return 1;
            }
            swLog.Flush();

            txtTanggalDaftar.Text = strTanggalDaftar1;

            return 0;
        } // ReadTanggalDaftar()

        private int ReadSaldo(ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // Read Binary Saldo, block 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16; // Block 0x16; Saldo
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Init Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteSaldo = new byte[8];

                Buffer.BlockCopy(RecvBuff, 0, byteSaldo, 0, 8);

                double dSaldo = BitConverter.ToDouble(byteSaldo, 0);
                txtSaldo.Text = dSaldo.ToString();
                // string strNIK2 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Init Saldo " + dSaldo.ToString());
                // MessageBox.Show("Read Binary Init Saldo " + dSaldo.ToString());
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Init Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Init Saldo.";
                MessageBox.Show("ERROR: Failed to Read Binary Init Saldo.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadSaldo()

        private void txtSaldo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                       (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }

        }

        private int ReadCardInit()
        {
            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text, ModWinsCard.SCARD_SHARE_SHARED,
                    ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.Flush();
                toolStripStatusLabel1.Text = "Failed to connect to card " + readerToolStripMenuItem.Text;
                MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                return 1;
            }
            else
            {
                // MessageBox.Show("Successful connection to " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Successful connection to " + readerToolStripMenuItem.Text);
                toolStripStatusLabel1.Text = "Successful connection to " + readerToolStripMenuItem.Text;
            }

            // toolStripStatusLabel1.Text = "Testing...";

            byte[] receivedUID = new byte[10];
            ModWinsCard.SCARD_IO_REQUEST request = new ModWinsCard.SCARD_IO_REQUEST();
            // request.dwProtocol = 1; //SCARD_PROTOCOL_T1);
            request.dwProtocol = Protocol;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(ModWinsCard.SCARD_IO_REQUEST));
            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            swLog.WriteLine("Protocol: " + Protocol.ToString());

            int outBytes = receivedUID.Length;
            int status = ModWinsCard.SCardTransmit(hCard, ref request, ref sendBytes[0],
                sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            byte[] UID = new byte[8];
            byte[] result = new byte[2];
            swLog.WriteLine("GET UID");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                UID = receivedUID.Take(outBytes - 2).ToArray();

                string hex = BitConverter.ToString(UID);
                // MessageBox.Show("UID: " + hex);
                result[0] = receivedUID[outBytes - 2];
                result[1] = receivedUID[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString());
                swLog.WriteLine("UID: " + hex + "; Response: " + hex2);
                if (hex2 == "90-00")
                {
                    swLog.WriteLine("GET UID: successful.");
                }
                else
                {
                    swLog.WriteLine("GET UID: failed.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "GET UID: failed.";
                    MessageBox.Show("GET UID: failed.");
                    return 2;
                }
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to GET UID.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to GET UID.";
                MessageBox.Show("ERROR: Failed to GET UID.");
                return 3;
            }

            swLog.Flush();

            // Load Key - Default Mifare FF key, P1=0x20 means in non volatile reader memory, P2-key number
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x82;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x06;
            SendBuff[5] = 0xFF;
            SendBuff[6] = 0xFF;
            SendBuff[7] = 0xFF;
            SendBuff[8] = 0xFF;
            SendBuff[9] = 0xFF;
            SendBuff[10] = 0xFF;

            int sendLength = 11;

            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Load Key - Default Mifare FF key");

            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Load Default Mifare FF key.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Load Default Mifare FF key.";
                MessageBox.Show("ERROR: Failed to Load Default Mifare FF key.");
                return 4;
            }
            swLog.Flush();

            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x01;     // Block Number 0x01
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            // sendLength = 6;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x01");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x01.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x01.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x01.");
                return 5;
            }
            swLog.Flush();
            toolStripStatusLabel1.Text = "SUCCESS: ReadCardInit().";

            return 0;
        } // ReadCardInit()

        private int GeneralAuthenticate(byte blockNumber, ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = blockNumber;     // Block Number
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x" + blockNumber.ToString("X2"));
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                            "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x" + blockNumber.ToString("X2"));
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x" + blockNumber.ToString("X2");
                MessageBox.Show("ERROR: Failed to authenticate block 0x" + blockNumber.ToString("X2"));
                return 1;
            }
            swLog.Flush();

            return 0;
        } // GeneralAuthenticate(byte blockNumber)

        int ReadTransNum(byte blockNumber, ModWinsCard.SCARD_IO_REQUEST request,
                            ref UInt32 lastTransNumber, ref byte lastBlock)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // Read Binary from blockNumber
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = blockNumber; // blockNumber; 0x2C
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Last Transaction Number");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteNumber = new byte[4];
                lastBlock = RecvBuff[4];

                Buffer.BlockCopy(RecvBuff, 0, byteNumber, 0, 4);

                lastTransNumber = BitConverter.ToUInt32(byteNumber, 0);

                swLog.WriteLine("Read Binary Last Transaction Number " + lastTransNumber.ToString());
                swLog.WriteLine("Read Binary Last Block " + lastBlock.ToString());
                // txtSaldo.Text = dSaldo.ToString();
                // MessageBox.Show("Read Binary Init Saldo " + dSaldo.ToString());
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Last Transaction Number.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Last Transaction Number.";
                MessageBox.Show("ERROR: Failed to Read Binary Last Transaction Number.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadTransNum()

        private int WriteTransaction(byte nextBlock, UInt32 transNumber, string tanggal,
                                string waktu, TransCode transCode,
                                double bobotBeras, double saldoBeras,
                                ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // byte one = 0x01;
            byte nextBlock2 = nextBlock;
            byte nextBlock3 = nextBlock;

            nextBlock2++;
            nextBlock3++;
            nextBlock3++;

            GeneralAuthenticate(nextBlock, request);

            swLog.WriteLine("WriteTransaction(" + nextBlock.ToString() + ", " +
                                transNumber.ToString() + ", " + tanggal + ", " +
                                waktu + ", " + transCode.ToString() + ", " +
                                bobotBeras.ToString("0.00") + ", " + 
                                saldoBeras.ToString("0.00"));

            // Update Binary to nextBlock
            // nextTransNumber (4 bytes) and tanggal (12 bytes)

            // nextTransNumber (4 bytes)
            byte[] byteTransNumber = BitConverter.GetBytes(transNumber);
            byte[] byteTanggal = Encoding.ASCII.GetBytes(tanggal);

            // Update Binary nextTransNumber to nextBlock
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock;     // Block number
            SendBuff[4] = 0x10;          // initSaldo

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            // nextTransNumber (4 bytes)
            Buffer.BlockCopy(byteTransNumber, 0, SendBuff, 5, 4);

            // tanggal (12 bytes)
            Buffer.BlockCopy(byteTanggal, 0, SendBuff, 9, byteTanggal.Length);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary transNumber dan tanggal");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary transNumber dan tanggal.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary transNumber dan tanggal.";
                MessageBox.Show("ERROR: Failed to Update Binary transNumber dan tanggal.");
                return 1;
            }
            swLog.Flush();

            // Read Binary transNumber dan tanggal from nextBlock
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary transNumber dan tanggal.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteNumber2 = new byte[4];
                byte[] byteTanggal2 = new byte[12];

                Array.Clear(byteTanggal2, 0, 12);

                Buffer.BlockCopy(RecvBuff, 0, byteNumber2, 0, 4);
                Buffer.BlockCopy(RecvBuff, 4, byteTanggal2, 0, 12);

                UInt32 transNumber2 = BitConverter.ToUInt32(byteNumber2, 0);
                string strTanggal2 = Encoding.ASCII.GetString(byteTanggal2, 0, 10);

                // double dSaldo = BitConverter.ToDouble(byteSaldo, 0);
                // string strNIK2 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary transNumber " + transNumber2.ToString());
                swLog.WriteLine("Read Binary tanggal " + strTanggal2);
                // txtSaldo.Text = dSaldo.ToString();
                // MessageBox.Show("Read Binary Init Saldo " + dSaldo.ToString());
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary transNumber dan tanggal.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary transNumber dan tanggal.";
                MessageBox.Show("ERROR: Failed to Read Binary transNumber dan tanggal.");
                return 1;
            }
            swLog.Flush();

            // Update Binary waktu (12 bytes) and TransCode (4 bytes) to nextBlock2
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock2;       // Block number
            SendBuff[4] = 0x10;             // waktu and TransCode

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            byte[] byteWaktu = Encoding.ASCII.GetBytes(waktu);

            // waktu 12 bytes
            Buffer.BlockCopy(byteWaktu, 0, SendBuff, 5, byteWaktu.Length);

            byte byteCode = (byte)transCode;

            // 5 + 12 = 17
            SendBuff[17] = byteCode;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary waktu dan transCode");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary waktu dan transCode.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary waktu dan transCode.";
                MessageBox.Show("ERROR: Failed to Update Binary waktu dan transCode.");
                return 1;
            }
            swLog.Flush();

            // Read Binary waktu dan transCode from nextBlock2
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock2; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary waktu dan transCode.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteWaktu2 = new byte[12];

                Array.Clear(byteWaktu2, 0, 12);

                Buffer.BlockCopy(RecvBuff, 0, byteWaktu2, 0, 12);

                byte byteCode2 = RecvBuff[12];

                string strWaktu2 = Encoding.ASCII.GetString(byteWaktu2, 0, 8);

                swLog.WriteLine("Read Binary waktu " + strWaktu2);
                swLog.WriteLine("Read Binary transCode " + byteCode2.ToString());

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary waktu dan transCode.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary waktu dan transCode.";
                MessageBox.Show("ERROR: Failed to Read Binary waktu dan transCode.");
                return 1;
            }
            swLog.Flush();

            // Update Binary bobotBeras (8 bytes) and saldoBeras (8 bytes) to nextBlock3
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock3;       // Block number
            SendBuff[4] = 0x10;             // bobotBeras dan saldoBeras

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            byte[] byteBobotBeras = BitConverter.GetBytes(bobotBeras);
            // bobotBeras 8 bytes; double
            Buffer.BlockCopy(byteBobotBeras, 0, SendBuff, 5, 8);

            // saldoBeras 8 bytes; double
            byte[] byteSaldoBeras = BitConverter.GetBytes(saldoBeras);
            Buffer.BlockCopy(byteSaldoBeras, 0, SendBuff, 13, 8);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary bobotBeras dan saldoBeras");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary bobotBeras dan saldoBeras.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary bobotBeras dan saldoBeras.";
                MessageBox.Show("ERROR: Failed to Update Binary bobotBeras dan saldoBeras.");
                return 1;
            }
            swLog.Flush();

            // Read Binary bobotBeras dan saldoBeras from nextBlock3
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock3; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary bobotBeras dan saldoBeras.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteBobotBeras2 = new byte[8];

                Array.Clear(byteBobotBeras2, 0, 8);
                Buffer.BlockCopy(RecvBuff, 0, byteBobotBeras2, 0, 8);
                double bobotBeras2 = BitConverter.ToDouble(byteBobotBeras2, 0);

                byte[] byteSaldoBeras2 = new byte[8];

                Array.Clear(byteSaldoBeras2, 0, 8);
                Buffer.BlockCopy(RecvBuff, 8, byteSaldoBeras2, 0, 8);
                double saldoBeras2 = BitConverter.ToDouble(byteSaldoBeras2, 0);

                swLog.WriteLine("Read Binary bobotBeras " + bobotBeras2.ToString("0.00") +
                                    ", saldoBeras " + saldoBeras2.ToString("0.00"));

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary bobotBeras dan saldoBeras.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary bobotBeras dan saldoBeras.";
                MessageBox.Show("ERROR: Failed to Read Binary bobotBeras dan saldoBeras.");
                return 1;
            }
            swLog.Flush();

            GeneralAuthenticate(0x2C, request);

            // Update Binary transNumber (4 bytes) and lastBlock (1 byte) to 0x2C
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x2C;       // Block number 0x2C
            SendBuff[4] = 0x10;       // transNumber and lastBlock

            byte lastBlock = nextBlock;

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            // transNumber, 4 bytes
            Buffer.BlockCopy(byteTransNumber, 0, SendBuff, 5, 4);

            // lastBlock, 1 byte
            SendBuff[9] = lastBlock;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary transNumber dan lastBlock");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary transNumber dan lastBlock.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary transNumber dan lastBlock.";
                MessageBox.Show("ERROR: Failed to Update Binary transNumber dan lastBlock.");
                return 1;
            }
            swLog.Flush();

            // Read Binary transNumber dan lastBlock from 0x2C
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x2C; // Block number 0x2C
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary transNumber dan lastBlock.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteTransNumber2 = new byte[4];

                Array.Clear(byteTransNumber2, 0, 4);
                Buffer.BlockCopy(RecvBuff, 0, byteTransNumber2, 0, 4);
                UInt32 transNumber3 = BitConverter.ToUInt32(byteTransNumber2, 0);

                byte lastBlock2 = RecvBuff[5];

                swLog.WriteLine("Read Binary transNumber " + transNumber3.ToString() +
                                    ", lastBlock " + lastBlock2.ToString());

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary transNumber dan lastBlock.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary transNumber dan lastBlock.";
                MessageBox.Show("ERROR: Failed to Read Binary transNumber dan lastBlock.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteTransaction()

        private int LoadKey(ModWinsCard.SCARD_IO_REQUEST request)
        {
            int outBytes;
            int status;
            int sendLength;

            byte[] result = new byte[2];

            // Load Key - Default Mifare FF key, P1=0x20 means in non volatile reader memory, P2-key number
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x82;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x06;
            SendBuff[5] = 0xFF;
            SendBuff[6] = 0xFF;
            SendBuff[7] = 0xFF;
            SendBuff[8] = 0xFF;
            SendBuff[9] = 0xFF;
            SendBuff[10] = 0xFF;

            sendLength = 11;

            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Load Key - Default Mifare FF key");

            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Load Default Mifare FF key.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Load Default Mifare FF key.";
                MessageBox.Show("ERROR: Failed to Load Default Mifare FF key.");
                return 4;
            }
            swLog.Flush();

            return 0;
        } // LoadKey()
        private int WriteInitSaldo(double initSaldo)
        {
            int outBytes;
            int status;
            int sendLength;

            byte[] receivedUID = new byte[10];
            byte[] UID = new byte[8];
            byte[] result = new byte[2];

            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            // write initSaldo to card

            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text, 
                ModWinsCard.SCARD_SHARE_SHARED, 
                ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1, 
                ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.Flush();
                toolStripStatusLabel1.Text = "Failed to connect to card " + readerToolStripMenuItem.Text;
                MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                return 1;
            }
            else
            {
                // MessageBox.Show("Successful connection to " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Successful connection to " + readerToolStripMenuItem.Text);
                toolStripStatusLabel1.Text = "Successful connection to " + readerToolStripMenuItem.Text;
            }

            ModWinsCard.SCARD_IO_REQUEST request = new ModWinsCard.SCARD_IO_REQUEST();
            
            request.dwProtocol = Protocol;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(ModWinsCard.SCARD_IO_REQUEST));
            swLog.WriteLine("Protocol: " + Protocol.ToString());

            outBytes = receivedUID.Length;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref sendBytes[0],
                sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            swLog.WriteLine("GET UID");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                UID = receivedUID.Take(outBytes - 2).ToArray();

                string hex = BitConverter.ToString(UID);
                // MessageBox.Show("UID: " + hex);
                result[0] = receivedUID[outBytes - 2];
                result[1] = receivedUID[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString());
                swLog.WriteLine("UID: " + hex + "; Response: " + hex2);
                if (hex2 == "90-00")
                {
                    swLog.WriteLine("GET UID: successful.");
                }
                else
                {
                    swLog.WriteLine("GET UID: failed.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "GET UID: failed.";
                    MessageBox.Show("GET UID: failed.");
                    return 2;
                }
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to GET UID.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to GET UID.";
                MessageBox.Show("ERROR: Failed to GET UID.");
                return 3;
            }

            swLog.Flush();

            LoadKey(request);

            GeneralAuthenticate(0x14, request);

            // Update Binary initSaldo to Block number 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16;     // Block number 0x16
            SendBuff[4] = 0x10;     // initSaldo

            byte[] byteInitSaldoTemp = BitConverter.GetBytes(initSaldo);

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteInitSaldoTemp, 0, SendBuff, 5, 8);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;    
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Init Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Init Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Init Saldo.";
                MessageBox.Show("ERROR: Failed to Update Binary Init Saldo.");
                return 1;
            }
            swLog.Flush();

            txtSaldo.Text = initSaldo.ToString();

            /****
            // Read Binary Saldo, block 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16; // Block 0x16; Saldo
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Init Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteSaldo = new byte[8];

                Buffer.BlockCopy(RecvBuff, 0, byteSaldo, 0, 8);

                double dSaldo = BitConverter.ToDouble(byteSaldo, 0);
                swLog.WriteLine("Read Binary Init Saldo " + dSaldo.ToString());
                txtSaldo.Text = dSaldo.ToString();
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Init Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Init Saldo.";
                MessageBox.Show("ERROR: Failed to Read Binary Init Saldo.");
                return 1;
            }
            swLog.Flush();
            ***/

            // General Authenticate block 0x2C
            GeneralAuthenticate(0x02C, request);

            // Read last transaction number from block 0x2C

            UInt32 lastTransNumber = 0;
            byte lastBlock = 0;

            retCode = ReadTransNum(0x2C, request, ref lastTransNumber, ref lastBlock);

            UInt32 nextTransNumber = lastTransNumber + 1;
            byte nextBlock = 0;

            if ( lastBlock == 0 )
            {
                nextBlock = TransNumberBlocks[0];
            } else {
                for (int i = 0; i < 5; i++)
                {
                    if (lastBlock == TransNumberBlocks[i])
                    {
                        if (i == 4)
                        {
                            nextBlock = TransNumberBlocks[0];
                            break;
                        }
                        else
                        {
                            nextBlock = TransNumberBlocks[i + 1];
                            break;
                        }
                    }
                }
            }

            DateTime time = DateTime.Now;
            string tanggal;
            string waktu;
            tanggal = time.ToString("dd/MM/yyyy");
            waktu = time.ToString("HH:mm:ss");

            WriteTransaction(nextBlock, nextTransNumber, tanggal, waktu, 
                                TransCode.InitSaldo, initSaldo, initSaldo, request);

            ReadTransactions(request);

            retCode = ModWinsCard.SCardDisconnect(hCard, ModWinsCard.SCARD_LEAVE_CARD);
            // Ret = SCardDisconnect(hCard, SCARD_LEAVE_CARD);

            return 0;
        } // WriteInitSaldo()

        private int WriteTopupSaldo(double topupSaldo)
        {
            // read current balance
            // add topup to current balance
            // write current balance to card

            int outBytes;
            int status;
            int sendLength;

            byte[] receivedUID = new byte[10];
            byte[] UID = new byte[8];
            byte[] result = new byte[2];

            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text,
                ModWinsCard.SCARD_SHARE_SHARED,
                ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1,
                ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.Flush();
                toolStripStatusLabel1.Text = "Failed to connect to card " + readerToolStripMenuItem.Text;
                MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                return 1;
            }
            else
            {
                // MessageBox.Show("Successful connection to " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Successful connection to " + readerToolStripMenuItem.Text);
                toolStripStatusLabel1.Text = "Successful connection to " + readerToolStripMenuItem.Text;
            }

            // toolStripStatusLabel1.Text = "Testing...";

            receivedUID = new byte[10];
            ModWinsCard.SCARD_IO_REQUEST request = new ModWinsCard.SCARD_IO_REQUEST();
            // request.dwProtocol = 1; //SCARD_PROTOCOL_T1);
            request.dwProtocol = Protocol;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(ModWinsCard.SCARD_IO_REQUEST));
            sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            swLog.WriteLine("Protocol: " + Protocol.ToString());

            outBytes = receivedUID.Length;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref sendBytes[0],
                sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            swLog.WriteLine("GET UID");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                UID = receivedUID.Take(outBytes - 2).ToArray();

                string hex = BitConverter.ToString(UID);
                // MessageBox.Show("UID: " + hex);
                result[0] = receivedUID[outBytes - 2];
                result[1] = receivedUID[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString());
                swLog.WriteLine("UID: " + hex + "; Response: " + hex2);
                if (hex2 == "90-00")
                {
                    swLog.WriteLine("GET UID: successful.");
                }
                else
                {
                    swLog.WriteLine("GET UID: failed.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "GET UID: failed.";
                    MessageBox.Show("GET UID: failed.");
                    return 2;
                }
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to GET UID.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to GET UID.";
                MessageBox.Show("ERROR: Failed to GET UID.");
                return 3;
            }

            swLog.Flush();

            LoadKey(request);

            GeneralAuthenticate(0x14, request);

            // Read Binary Saldo, block 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16; // Block 0x16; Saldo
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            double currentSaldo = 0.0;
            swLog.WriteLine("Read Binary Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteSaldo = new byte[8];

                Buffer.BlockCopy(RecvBuff, 0, byteSaldo, 0, 8);

                double dSaldo = BitConverter.ToDouble(byteSaldo, 0);
                swLog.WriteLine("Read Binary Saldo " + dSaldo.ToString());

                // Add topup to saldo
                currentSaldo = dSaldo + topupSaldo;
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Saldo.";
                MessageBox.Show("ERROR: Failed to Read Binary Init Saldo.");
                return 1;
            }
            swLog.Flush();

            // Update Binary Saldo to Block number 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16;     // Block number 0x16
            SendBuff[4] = 0x10;     // initSaldo

            byte[] byteTopupSaldoTemp = BitConverter.GetBytes(currentSaldo);

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteTopupSaldoTemp, 0, SendBuff, 5, 8);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Topup Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Topup Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Topup Saldo.";
                MessageBox.Show("ERROR: Failed to Update Binary Topup Saldo.");
                return 1;
            }
            swLog.Flush();

            txtSaldo.Text = currentSaldo.ToString();

            /*****
            // Read Binary Current Saldo, block 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16; // Block 0x16; Saldo
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // double currentSaldo = 0.0;
            swLog.WriteLine("Read Binary Current Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteSaldo = new byte[8];

                Buffer.BlockCopy(RecvBuff, 0, byteSaldo, 0, 8);

                double dSaldo = BitConverter.ToDouble(byteSaldo, 0);
                // string strNIK2 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                txtSaldo.Text = dSaldo.ToString();
                swLog.WriteLine("Read Binary Current Saldo " + dSaldo.ToString());

                // currentSaldo = dSaldo + topupSaldo;
                currentSaldo = dSaldo;
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Current Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Current Saldo.";
                MessageBox.Show("ERROR: Failed to Read Binary Current Saldo.");
                return 1;
            }
            swLog.Flush();
            ****/

            // General Authenticate block 0x2C
            GeneralAuthenticate(0x02C, request);

            // Read last transaction number from block 0x2C

            UInt32 lastTransNumber = 0;
            byte lastBlock = 0;

            retCode = ReadTransNum(0x2C, request, ref lastTransNumber, ref lastBlock);

            UInt32 nextTransNumber = lastTransNumber + 1;
            byte nextBlock = 0;

            if (lastBlock == 0)
            {
                nextBlock = TransNumberBlocks[0];
            }
            else
            {
                for (int i = 0; i < 5; i++)
                {
                    if (lastBlock == TransNumberBlocks[i])
                    {
                        if (i == 4)
                        {
                            nextBlock = TransNumberBlocks[0];
                            break;
                        }
                        else
                        {
                            nextBlock = TransNumberBlocks[i + 1];
                            break;
                        }
                    }
                }
            }

            DateTime time = DateTime.Now;
            string tanggal;
            string waktu;
            tanggal = time.ToString("dd/MM/yyyy");
            waktu = time.ToString("HH:mm:ss");

            WriteTransaction(nextBlock, nextTransNumber, tanggal, waktu,
                                TransCode.TopupSaldo, topupSaldo, currentSaldo, request);

            ReadTransactions(request);

            retCode = ModWinsCard.SCardDisconnect(hCard, ModWinsCard.SCARD_LEAVE_CARD);
            // Ret = SCardDisconnect(hCard, SCARD_LEAVE_CARD);

            return 0;
        } // WriteTopupSaldo()

        private int WriteBagiBeras(double bagiBeras)
        {
            // read current balance
            // subtract bagiBeras from current balance
            // write current balance to card

            int outBytes;
            int status;
            int sendLength;

            byte[] receivedUID = new byte[10];
            byte[] UID = new byte[8];
            byte[] result = new byte[2];

            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text,
                ModWinsCard.SCARD_SHARE_SHARED,
                ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1,
                ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.Flush();
                toolStripStatusLabel1.Text = "Failed to connect to card " + readerToolStripMenuItem.Text;
                MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                return 1;
            }
            else
            {
                // MessageBox.Show("Successful connection to " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Successful connection to " + readerToolStripMenuItem.Text);
                toolStripStatusLabel1.Text = "Successful connection to " + readerToolStripMenuItem.Text;
            }

            // toolStripStatusLabel1.Text = "Testing...";

            receivedUID = new byte[10];
            ModWinsCard.SCARD_IO_REQUEST request = new ModWinsCard.SCARD_IO_REQUEST();
            // request.dwProtocol = 1; //SCARD_PROTOCOL_T1);
            request.dwProtocol = Protocol;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(ModWinsCard.SCARD_IO_REQUEST));

            swLog.WriteLine("Protocol: " + Protocol.ToString());

            outBytes = receivedUID.Length;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref sendBytes[0],
                sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            swLog.WriteLine("GET UID");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                UID = receivedUID.Take(outBytes - 2).ToArray();

                string hex = BitConverter.ToString(UID);
                // MessageBox.Show("UID: " + hex);
                result[0] = receivedUID[outBytes - 2];
                result[1] = receivedUID[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString());
                swLog.WriteLine("UID: " + hex + "; Response: " + hex2);
                if (hex2 == "90-00")
                {
                    swLog.WriteLine("GET UID: successful.");
                }
                else
                {
                    swLog.WriteLine("GET UID: failed.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "GET UID: failed.";
                    MessageBox.Show("GET UID: failed.");
                    return 2;
                }
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to GET UID.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to GET UID.";
                MessageBox.Show("ERROR: Failed to GET UID.");
                return 3;
            }

            swLog.Flush();

            LoadKey(request);

            /*****
            // Load Key - Default Mifare FF key, P1=0x20 means in non volatile reader memory, P2-key number
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x82;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x06;
            SendBuff[5] = 0xFF;
            SendBuff[6] = 0xFF;
            SendBuff[7] = 0xFF;
            SendBuff[8] = 0xFF;
            SendBuff[9] = 0xFF;
            SendBuff[10] = 0xFF;

            int sendLength = 11;

            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Load Key - Default Mifare FF key");

            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Load Default Mifare FF key.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Load Default Mifare FF key.";
                MessageBox.Show("ERROR: Failed to Load Default Mifare FF key.");
                return 4;
            }
            swLog.Flush();
            ****/

            GeneralAuthenticate(0x14, request);

            /****
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x14;     // Block Number 0x14
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            // sendLength = 6;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x14");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x14.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x14.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x14.");
                return 5;
            }
            swLog.Flush();
            ***/

            // Read Binary Saldo, block 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16; // Block 0x16; Saldo
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            double currentSaldo = 0.0;
            swLog.WriteLine("Read Binary Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteSaldo = new byte[8];

                Buffer.BlockCopy(RecvBuff, 0, byteSaldo, 0, 8);

                double dSaldo = BitConverter.ToDouble(byteSaldo, 0);
                // string strNIK2 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Current Saldo " + dSaldo.ToString());
                // MessageBox.Show("Read Binary Init Saldo " + dSaldo.ToString());

                if ( dSaldo >= bagiBeras )
                {
                    currentSaldo = dSaldo - bagiBeras;
                } else
                {
                    swLog.WriteLine("ERROR: bagiBeras lebih besar daripada Saldo.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "ERROR: bagiBeras lebih besar daripada Saldo.";
                    MessageBox.Show("ERROR: bagiBeras lebih besar daripada Saldo.");
                    return 1;
                }

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Saldo.";
                MessageBox.Show("ERROR: Failed to Read Binary Saldo.");
                return 1;
            }
            swLog.Flush();

            // Update currentSaldo

            // Update Binary currentSaldo to Block number 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16;     // Block number 0x16
            SendBuff[4] = 0x10;     // currentSaldo

            byte[] byteCurrentSaldoTemp = BitConverter.GetBytes(currentSaldo);

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteCurrentSaldoTemp, 0, SendBuff, 5, 8);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Current Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Current Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Current Saldo.";
                MessageBox.Show("ERROR: Failed to Update Binary Current Saldo.");
                return 1;
            }
            swLog.Flush();

            txtSaldo.Text = currentSaldo.ToString();

            /****
            // Read Binary Current Saldo, block 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16; // Block 0x16; Current Saldo
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // double currentSaldo = 0.0;
            swLog.WriteLine("Read Binary Current Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteSaldo = new byte[8];

                Buffer.BlockCopy(RecvBuff, 0, byteSaldo, 0, 8);

                double dSaldo = BitConverter.ToDouble(byteSaldo, 0);
                currentSaldo = dSaldo;
                // string strNIK2 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                txtSaldo.Text = dSaldo.ToString();
                swLog.WriteLine("Read Binary Current Saldo " + dSaldo.ToString());

                // currentSaldo = dSaldo + topupSaldo;
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Init Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Init Saldo.";
                MessageBox.Show("ERROR: Failed to Read Binary Init Saldo.");
                return 1;
            }
            swLog.Flush();
            ****/

            // General Authenticate block 0x2C
            GeneralAuthenticate(0x02C, request);

            // Read last transaction number from block 0x2C

            UInt32 lastTransNumber = 0;
            byte lastBlock = 0;

            retCode = ReadTransNum(0x2C, request, ref lastTransNumber, ref lastBlock);

            UInt32 nextTransNumber = lastTransNumber + 1;
            byte nextBlock = 0;

            if (lastBlock == 0)
            {
                nextBlock = TransNumberBlocks[0];
            }
            else
            {
                for (int i = 0; i < 5; i++)
                {
                    if (lastBlock == TransNumberBlocks[i])
                    {
                        if (i == 4)
                        {
                            nextBlock = TransNumberBlocks[0];
                            break;
                        }
                        else
                        {
                            nextBlock = TransNumberBlocks[i + 1];
                            break;
                        }
                    }
                }
            }

            DateTime time = DateTime.Now;
            string tanggal;
            string waktu;
            tanggal = time.ToString("dd/MM/yyyy");
            waktu = time.ToString("HH:mm:ss");

            WriteTransaction(nextBlock, nextTransNumber, tanggal, waktu,
                                TransCode.BagiBeras, bagiBeras, currentSaldo, request);

            ReadTransactions(request);

            swLog.WriteLine("SUCCESS: Bagi Beras.");
            swLog.Flush();
            toolStripStatusLabel1.Text = "SUCCESS: Bagi Beras.";

            retCode = ModWinsCard.SCardDisconnect(hCard, ModWinsCard.SCARD_LEAVE_CARD);

            return 0;
        } // WriteBagiBeras()

        private void btnTopup_Click(object sender, EventArgs e)
        {
            int rc;

            // MessageBox.Show(btnTopup.Text);
            if ( btnTopup.Text == "&Topup Saldo (kg)" )
            {
                rc = ReadCardInit();
                if ( rc != 0 )
                {
                    swLog.WriteLine("ERROR: Failed to ReadCardInit().");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "ERROR: Failed to ReadCardInit().";
                    MessageBox.Show("ERROR: Failed to ReadCardInit().");
                } else
                {
                    txtTopup.Enabled = true;
                    btnTopup.Text = "Apply Topup (kg)";
                    txtTopup.Text = "";
                    txtTopup.Focus();
                }
            } else if ( btnTopup.Text == "Apply Topup (kg)" )
            {
                if (txtTopup.Text == "")
                {
                    txtTopup.Enabled = false;
                    btnTopup.Text = "&Topup Saldo (kg)";
                    return;
                }

                double topupSaldo = double.Parse(txtTopup.Text);
                topupSaldo = Math.Round(topupSaldo, 2);
                txtTopup.Text = topupSaldo.ToString();

                rc = WriteTopupSaldo(topupSaldo);
                if (rc != 0)
                {
                    swLog.WriteLine("ERROR: Failed to WriteTopupSaldo().");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "ERROR: Failed to WriteTopupSaldo().";
                    txtTopup.Enabled = false;
                    btnTopup.Text = "&Topup Saldo (kg)";
                    return;
                }
                toolStripStatusLabel1.Text = "SUCCESS: Topup Saldo.";

                txtTopup.Enabled = false;
                btnTopup.Text = "&Topup Saldo (kg)";
            }
        } // btnTopup_Click()

        private int ReadTransRecord(int idx, byte blockNumber, 
                            ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            int retCode;
            byte nextBlock2;
            byte nextBlock3;

            nextBlock2 = blockNumber;
            nextBlock3 = blockNumber;

            nextBlock2++;
            nextBlock3++;
            nextBlock3++;

            retCode = GeneralAuthenticate(blockNumber, request);

            // Read Binary transNumber dan tanggal from nextBlock
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = blockNumber; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary transNumber dan tanggal.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteNumber2 = new byte[4];
                byte[] byteTanggal2 = new byte[12];

                Array.Clear(byteTanggal2, 0, 12);

                Buffer.BlockCopy(RecvBuff, 0, byteNumber2, 0, 4);
                Buffer.BlockCopy(RecvBuff, 4, byteTanggal2, 0, 12);

                UInt32 transNumber2 = BitConverter.ToUInt32(byteNumber2, 0);
                string strTanggal2 = Encoding.ASCII.GetString(byteTanggal2, 0, 10);

                swLog.WriteLine("Read Binary transNumber " + transNumber2.ToString());
                swLog.WriteLine("Read Binary tanggal " + strTanggal2);

                transRecords[idx].transNumber = transNumber2.ToString();
                transRecords[idx].tanggalTrans = strTanggal2;

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary transNumber dan tanggal.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary transNumber dan tanggal.";
                MessageBox.Show("ERROR: Failed to Read Binary transNumber dan tanggal.");
                return 1;
            }
            swLog.Flush();

            // Read Binary waktu dan transCode from nextBlock2
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock2; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary waktu dan transCode.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteWaktu2 = new byte[12];

                Array.Clear(byteWaktu2, 0, 12);

                Buffer.BlockCopy(RecvBuff, 0, byteWaktu2, 0, 12);

                byte byteCode2 = RecvBuff[12];

                string strWaktu2 = Encoding.ASCII.GetString(byteWaktu2, 0, 8);

                swLog.WriteLine("Read Binary waktu " + strWaktu2);
                swLog.WriteLine("Read Binary transCode " + byteCode2.ToString());

                transRecords[idx].waktuTrans = strWaktu2;
                transRecords[idx].transCode = TransCodeString[byteCode2];

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary waktu dan transCode.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary waktu dan transCode.";
                MessageBox.Show("ERROR: Failed to Read Binary waktu dan transCode.");
                return 1;
            }
            swLog.Flush();

            // Read Binary bobotBeras dan saldoBeras from nextBlock3
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock3; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary bobotBeras dan saldoBeras.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteBobotBeras2 = new byte[8];

                Array.Clear(byteBobotBeras2, 0, 8);
                Buffer.BlockCopy(RecvBuff, 0, byteBobotBeras2, 0, 8);
                double bobotBeras2 = BitConverter.ToDouble(byteBobotBeras2, 0);

                byte[] byteSaldoBeras2 = new byte[8];

                Array.Clear(byteSaldoBeras2, 0, 8);
                Buffer.BlockCopy(RecvBuff, 8, byteSaldoBeras2, 0, 8);
                double saldoBeras2 = BitConverter.ToDouble(byteSaldoBeras2, 0);

                swLog.WriteLine("Read Binary bobotBeras " + bobotBeras2.ToString("0.00") +
                                    ", saldoBeras " + saldoBeras2.ToString("0.00"));

                transRecords[idx].bobotBeras = bobotBeras2.ToString("0.00");
                transRecords[idx].saldoBeras = saldoBeras2.ToString("0.00");

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary bobotBeras dan saldoBeras.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary bobotBeras dan saldoBeras.";
                MessageBox.Show("ERROR: Failed to Read Binary bobotBeras dan saldoBeras.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadTransRecord()

        private int ReadTransactions(ModWinsCard.SCARD_IO_REQUEST request)
        {
            int retCode;
            // block 0x1C, 0x20, 0x24, 0x28, 0x2C;
            byte[] blockNumbers = new byte[5];

            blockNumbers[0] = 0x18;
            blockNumbers[1] = 0x1C;
            blockNumbers[2] = 0x20;
            blockNumbers[3] = 0x24;
            blockNumbers[4] = 0x28;

            for(int i = 0; i<5; i++)
            {
                retCode = ReadTransRecord(i, blockNumbers[i], request);
            }

            PopulateDataGridView();
            return 0;
        }

        private int FindMax(int[] transNumbers, ref int maxIdx, ref int maxNumber)
        {
            for(int i=0; i<5; i++)
            {
                if (transNumbers[i] > maxNumber)
                {
                    maxNumber = transNumbers[i];
                    maxIdx = i;
                }
            }
            return 0;
        } // FindMax()

        private void PopulateDataGridView()
        {
            int[] transNumbers = new int[5];

            transNumbers[0] = int.Parse(transRecords[0].transNumber);
            transNumbers[1] = int.Parse(transRecords[1].transNumber);
            transNumbers[2] = int.Parse(transRecords[2].transNumber);
            transNumbers[3] = int.Parse(transRecords[3].transNumber);
            transNumbers[4] = int.Parse(transRecords[4].transNumber);

            int maxIdx = -1;
            int maxNumber = -1;

            FindMax(transNumbers, ref maxIdx, ref maxNumber);

            string[] row0 = new string[6];
            string[] row1 = new string[6];
            string[] row2 = new string[6];
            string[] row3 = new string[6];
            string[] row4 = new string[6];

            if (maxIdx == 0)
            {
                row0[0] = transRecords[1].transNumber;
                row0[1] = transRecords[1].tanggalTrans;
                row0[2] = transRecords[1].waktuTrans;
                row0[3] = transRecords[1].transCode;
                row0[4] = transRecords[1].bobotBeras;
                row0[5] = transRecords[1].saldoBeras;

                row1[0] = transRecords[2].transNumber;
                row1[1] = transRecords[2].tanggalTrans;
                row1[2] = transRecords[2].waktuTrans;
                row1[3] = transRecords[2].transCode;
                row1[4] = transRecords[2].bobotBeras;
                row1[5] = transRecords[2].saldoBeras;

                row2[0] = transRecords[3].transNumber;
                row2[1] = transRecords[3].tanggalTrans;
                row2[2] = transRecords[3].waktuTrans;
                row2[3] = transRecords[3].transCode;
                row2[4] = transRecords[3].bobotBeras;
                row2[5] = transRecords[3].saldoBeras;

                row3[0] = transRecords[4].transNumber;
                row3[1] = transRecords[4].tanggalTrans;
                row3[2] = transRecords[4].waktuTrans;
                row3[3] = transRecords[4].transCode;
                row3[4] = transRecords[4].bobotBeras;
                row3[5] = transRecords[4].saldoBeras;

                row4[0] = transRecords[0].transNumber;
                row4[1] = transRecords[0].tanggalTrans;
                row4[2] = transRecords[0].waktuTrans;
                row4[3] = transRecords[0].transCode;
                row4[4] = transRecords[0].bobotBeras;
                row4[5] = transRecords[0].saldoBeras;
            }
            else if (maxIdx == 1)
            {
                row0[0] = transRecords[2].transNumber;
                row0[1] = transRecords[2].tanggalTrans;
                row0[2] = transRecords[2].waktuTrans;
                row0[3] = transRecords[2].transCode;
                row0[4] = transRecords[2].bobotBeras;
                row0[5] = transRecords[2].saldoBeras;

                row1[0] = transRecords[3].transNumber;
                row1[1] = transRecords[3].tanggalTrans;
                row1[2] = transRecords[3].waktuTrans;
                row1[3] = transRecords[3].transCode;
                row1[4] = transRecords[3].bobotBeras;
                row1[5] = transRecords[3].saldoBeras;

                row2[0] = transRecords[4].transNumber;
                row2[1] = transRecords[4].tanggalTrans;
                row2[2] = transRecords[4].waktuTrans;
                row2[3] = transRecords[4].transCode;
                row2[4] = transRecords[4].bobotBeras;
                row2[5] = transRecords[4].saldoBeras;

                row3[0] = transRecords[0].transNumber;
                row3[1] = transRecords[0].tanggalTrans;
                row3[2] = transRecords[0].waktuTrans;
                row3[3] = transRecords[0].transCode;
                row3[4] = transRecords[0].bobotBeras;
                row3[5] = transRecords[0].saldoBeras;

                row4[0] = transRecords[1].transNumber;
                row4[1] = transRecords[1].tanggalTrans;
                row4[2] = transRecords[1].waktuTrans;
                row4[3] = transRecords[1].transCode;
                row4[4] = transRecords[1].bobotBeras;
                row4[5] = transRecords[1].saldoBeras;
            }
            else if (maxIdx == 2)
            {
                row0[0] = transRecords[3].transNumber;
                row0[1] = transRecords[3].tanggalTrans;
                row0[2] = transRecords[3].waktuTrans;
                row0[3] = transRecords[3].transCode;
                row0[4] = transRecords[3].bobotBeras;
                row0[5] = transRecords[3].saldoBeras;

                row1[0] = transRecords[4].transNumber;
                row1[1] = transRecords[4].tanggalTrans;
                row1[2] = transRecords[4].waktuTrans;
                row1[3] = transRecords[4].transCode;
                row1[4] = transRecords[4].bobotBeras;
                row1[5] = transRecords[4].saldoBeras;

                row2[0] = transRecords[0].transNumber;
                row2[1] = transRecords[0].tanggalTrans;
                row2[2] = transRecords[0].waktuTrans;
                row2[3] = transRecords[0].transCode;
                row2[4] = transRecords[0].bobotBeras;
                row2[5] = transRecords[0].saldoBeras;

                row3[0] = transRecords[1].transNumber;
                row3[1] = transRecords[1].tanggalTrans;
                row3[2] = transRecords[1].waktuTrans;
                row3[3] = transRecords[1].transCode;
                row3[4] = transRecords[1].bobotBeras;
                row3[5] = transRecords[1].saldoBeras;

                row4[0] = transRecords[2].transNumber;
                row4[1] = transRecords[2].tanggalTrans;
                row4[2] = transRecords[2].waktuTrans;
                row4[3] = transRecords[2].transCode;
                row4[4] = transRecords[2].bobotBeras;
                row4[5] = transRecords[2].saldoBeras;
            }
            else if (maxIdx == 3)
            {
                row0[0] = transRecords[4].transNumber;
                row0[1] = transRecords[4].tanggalTrans;
                row0[2] = transRecords[4].waktuTrans;
                row0[3] = transRecords[4].transCode;
                row0[4] = transRecords[4].bobotBeras;
                row0[5] = transRecords[4].saldoBeras;

                row1[0] = transRecords[0].transNumber;
                row1[1] = transRecords[0].tanggalTrans;
                row1[2] = transRecords[0].waktuTrans;
                row1[3] = transRecords[0].transCode;
                row1[4] = transRecords[0].bobotBeras;
                row1[5] = transRecords[0].saldoBeras;

                row2[0] = transRecords[1].transNumber;
                row2[1] = transRecords[1].tanggalTrans;
                row2[2] = transRecords[1].waktuTrans;
                row2[3] = transRecords[1].transCode;
                row2[4] = transRecords[1].bobotBeras;
                row2[5] = transRecords[1].saldoBeras;

                row3[0] = transRecords[2].transNumber;
                row3[1] = transRecords[2].tanggalTrans;
                row3[2] = transRecords[2].waktuTrans;
                row3[3] = transRecords[2].transCode;
                row3[4] = transRecords[2].bobotBeras;
                row3[5] = transRecords[2].saldoBeras;

                row4[0] = transRecords[3].transNumber;
                row4[1] = transRecords[3].tanggalTrans;
                row4[2] = transRecords[3].waktuTrans;
                row4[3] = transRecords[3].transCode;
                row4[4] = transRecords[3].bobotBeras;
                row4[5] = transRecords[3].saldoBeras;
            } else if (maxIdx == 4)
            {
                row0[0] = transRecords[0].transNumber;
                row0[1] = transRecords[0].tanggalTrans;
                row0[2] = transRecords[0].waktuTrans;
                row0[3] = transRecords[0].transCode;
                row0[4] = transRecords[0].bobotBeras;
                row0[5] = transRecords[0].saldoBeras;

                row1[0] = transRecords[1].transNumber;
                row1[1] = transRecords[1].tanggalTrans;
                row1[2] = transRecords[1].waktuTrans;
                row1[3] = transRecords[1].transCode;
                row1[4] = transRecords[1].bobotBeras;
                row1[5] = transRecords[1].saldoBeras;

                row2[0] = transRecords[2].transNumber;
                row2[1] = transRecords[2].tanggalTrans;
                row2[2] = transRecords[2].waktuTrans;
                row2[3] = transRecords[2].transCode;
                row2[4] = transRecords[2].bobotBeras;
                row2[5] = transRecords[2].saldoBeras;

                row3[0] = transRecords[3].transNumber;
                row3[1] = transRecords[3].tanggalTrans;
                row3[2] = transRecords[3].waktuTrans;
                row3[3] = transRecords[3].transCode;
                row3[4] = transRecords[3].bobotBeras;
                row3[5] = transRecords[3].saldoBeras;

                row4[0] = transRecords[4].transNumber;
                row4[1] = transRecords[4].tanggalTrans;
                row4[2] = transRecords[4].waktuTrans;
                row4[3] = transRecords[4].transCode;
                row4[4] = transRecords[4].bobotBeras;
                row4[5] = transRecords[4].saldoBeras;
            }

            // dataGridView1.DataSource = null;

            do
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    try
                    {
                        dataGridView1.Rows.Remove(row);
                    }
                    catch (Exception) { }
                }
            } while (dataGridView1.Rows.Count > 1);

            if ( row0[0] != "0" && row0[3] != "None" )
            {
                dataGridView1.Rows.Add(row0);
            }
            if (row1[0] != "0" && row1[3] != "None")
            {
                dataGridView1.Rows.Add(row1);
            }

            if (row2[0] != "0" && row2[3] != "None")
            {
                dataGridView1.Rows.Add(row2);
            }

            if (row3[0] != "0" && row3[3] != "None")
            {
                dataGridView1.Rows.Add(row3);
            }

            if (row4[0] != "0" && row4[3] != "None")
            {
                dataGridView1.Rows.Add(row4);
            }

            // dataGridView1.Rows.Add(row0);
            // dataGridView1.Rows.Add(row1);
            // dataGridView1.Rows.Add(row2);
            // dataGridView1.Rows.Add(row3);
            // dataGridView1.Rows.Add(row4);
        }

        private void btnInitSaldo_Click(object sender, EventArgs e)
        {
            int rc;

            if (btnInitSaldo.Text == "I&nit Saldo (kg)")
            {
                rc = ReadCardInit();
                if (rc != 0)
                {
                    swLog.WriteLine("ERROR: Failed to ReadCardInit().");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "ERROR: Failed to ReadCardInit().";
                    MessageBox.Show("ERROR: Failed to ReadCardInit().");
                }
                else
                {
                    txtInitSaldo.Enabled = true;
                    btnInitSaldo.Text = "Apply Init (kg)";
                    txtInitSaldo.Text = "";
                    txtInitSaldo.Focus();
                }
            }
            else if (btnInitSaldo.Text == "Apply Init (kg)")
            {
                if ( txtInitSaldo.Text == "" )
                {
                    txtInitSaldo.Enabled = false;
                    btnInitSaldo.Text = "I&nit Saldo (kg)";
                    return;
                }

                //System.IFormatProvider cultureUS = new System.Globalization.CultureInfo("en-US");
                //System.IFormatProvider cultureFR = new System.Globalization.CultureInfo("fr-fr");
                //double saldomasuk = double.Parse(txtInitSaldo.Text, cultureFR); //rubah inputan koma jadi titik
                //Console.WriteLine("saldomasuk SEBESAR:");
                //Console.WriteLine(saldomasuk);
                double initSaldo = double.Parse(txtInitSaldo.Text);  //fenyakit

                initSaldo = Math.Round(initSaldo, 2);
                txtInitSaldo.Text = initSaldo.ToString();

                rc = WriteInitSaldo(initSaldo);
                if (rc != 0)
                {
                    swLog.WriteLine("ERROR: Failed to WriteInitSaldo().");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "ERROR: Failed to WriteInitSaldo().";
                    txtInitSaldo.Enabled = false;
                    btnInitSaldo.Text = "I&nit Saldo (kg)";
                    return;
                }
                toolStripStatusLabel1.Text = "SUCCESS: Init Saldo.";

                txtInitSaldo.Enabled = false;
                // txtInitSaldo.Text = "";
                btnInitSaldo.Text = "I&nit Saldo (kg)";
            }
        } // btnInitSaldo_Click()

        private void txtInitSaldo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                        (e.KeyChar != ',') && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
           if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            } 

            // only allow one decimal point
            //if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1)) //change decimal point coma or dot
            //{
            //   e.Handled = true;
            //}

            this.AcceptButton = btnInitSaldo;  //add function Enter As store data key
        }

        private void txtTopup_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                        (e.KeyChar != ',') && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }

            // only allow one decimal point
            //if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            //{
            //    e.Handled = true;
            //}
            this.AcceptButton = btnTopup;  //add function Enter As store data key
        }

        private void txtBagi_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                        (e.KeyChar != ',') && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',')
            {
                e.KeyChar = '.';
            }

            // only allow one decimal point
            //if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            //{
            //    e.Handled = true;
            // }
            this.AcceptButton = btnBagi;  //add function Enter As store data key
        }

        private void btnBagi_Click(object sender, EventArgs e)
        {
            int rc;

            if (btnBagi.Text == "Bagi Be&ras (kg)")
            {
                rc = ReadCardInit();
                if (rc != 0)
                {
                    swLog.WriteLine("ERROR: Failed to ReadCardInit().");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "ERROR: Failed to ReadCardInit().";
                    MessageBox.Show("ERROR: Failed to ReadCardInit().");
                }
                else
                {
                    txtBagi.Enabled = true;
                    btnBagi.Text = "Apply Bagi (kg)";
                    txtBagi.Text = "";
                    txtBagi.Focus();
                }
            }
            else if (btnBagi.Text == "Apply Bagi (kg)")
            {
                if ( txtBagi.Text == "")
                {
                    txtBagi.Enabled = false;
                    btnBagi.Text = "Bagi Be&ras (kg)";
                    return;
                }

                double bagiBeras = double.Parse(txtBagi.Text);
                bagiBeras = Math.Round(bagiBeras, 2);
                txtBagi.Text = bagiBeras.ToString();

                rc = WriteBagiBeras(bagiBeras);
                // rc = WriteInitSaldo(initSaldo);
                if (rc != 0)
                {
                    swLog.WriteLine("ERROR: Failed to WriteBagiBeras().");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "ERROR: Failed to WriteBagiBeras().";
                    txtInitSaldo.Enabled = false;
                    btnInitSaldo.Text = "I&nit Saldo (kg)";
                    return;
                }
                toolStripStatusLabel1.Text = "SUCCESS: Bagi Beras.";

                txtBagi.Enabled = false;
                btnBagi.Text = "Bagi Be&ras (kg)";
            }
        } // btnBagi_Click()

        private void txtNIKWilayah_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) // &&
                    // (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void txtNIKWilayah_TextChanged(object sender, EventArgs e)
        {
            if (((TextBox)sender).TextLength > 5)
                SendKeys.Send("{Tab}");
        }

        private int ClearTrans(byte nextBlock, ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // byte one = 0x01;
            byte nextBlock2 = nextBlock;
            byte nextBlock3 = nextBlock;

            nextBlock2++;
            nextBlock3++;
            nextBlock3++;

            GeneralAuthenticate(nextBlock, request);

            // Update Binary to nextBlock

            // Update Binary nextTransNumber to nextBlock
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock;     // Block number
            SendBuff[4] = 0x10;          // initSaldo

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary zeros");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary transNumber dan tanggal.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary transNumber dan tanggal.";
                MessageBox.Show("ERROR: Failed to Update Binary transNumber dan tanggal.");
                return 1;
            }
            swLog.Flush();

            // Update Binary zeros to nextBlock2
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock2;       // Block number
            SendBuff[4] = 0x10;             // waktu and TransCode

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary waktu dan transCode");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary waktu dan transCode.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary waktu dan transCode.";
                MessageBox.Show("ERROR: Failed to Update Binary waktu dan transCode.");
                return 1;
            }
            swLog.Flush();

            // Update Binary zeros to nextBlock3
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock3;       // Block number
            SendBuff[4] = 0x10;             // bobotBeras dan saldoBeras

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary bobotBeras dan saldoBeras");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary bobotBeras dan saldoBeras.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary bobotBeras dan saldoBeras.";
                MessageBox.Show("ERROR: Failed to Update Binary bobotBeras dan saldoBeras.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ClearTrans()

        private void btnClearTrans_Click(object sender, EventArgs e)
        {
            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text,
                            ModWinsCard.SCARD_SHARE_SHARED,
                            ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1,
                            ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.Flush();
                toolStripStatusLabel1.Text = "Failed to connect to card " + readerToolStripMenuItem.Text;
                MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                return;
            }
            else
            {
                // MessageBox.Show("Successful connection to " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Successful connection to " + readerToolStripMenuItem.Text);
                toolStripStatusLabel1.Text = "Successful connection to " + readerToolStripMenuItem.Text;
            }

            // toolStripStatusLabel1.Text = "Testing...";

            byte[] receivedUID = new byte[10];
            ModWinsCard.SCARD_IO_REQUEST request = new ModWinsCard.SCARD_IO_REQUEST();
            // request.dwProtocol = 1; //SCARD_PROTOCOL_T1);
            request.dwProtocol = Protocol;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(ModWinsCard.SCARD_IO_REQUEST));
            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            swLog.WriteLine("Protocol: " + Protocol.ToString());

            int outBytes = receivedUID.Length;
            int status = ModWinsCard.SCardTransmit(hCard, ref request, ref sendBytes[0],
                sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            byte[] UID = new byte[8];
            byte[] result = new byte[2];
            swLog.WriteLine("GET UID");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                UID = receivedUID.Take(outBytes - 2).ToArray();

                string hex = BitConverter.ToString(UID);
                // MessageBox.Show("UID: " + hex);
                result[0] = receivedUID[outBytes - 2];
                result[1] = receivedUID[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString());
                swLog.WriteLine("UID: " + hex + "; Response: " + hex2);
                if (hex2 == "90-00")
                {
                    swLog.WriteLine("GET UID: successful.");
                }
                else
                {
                    swLog.WriteLine("GET UID: failed.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "GET UID: failed.";
                    MessageBox.Show("GET UID: failed.");
                    return;
                }
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to GET UID.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to GET UID.";
                MessageBox.Show("ERROR: Failed to GET UID.");
                return;
            }

            swLog.Flush();

            // Load Key - Default Mifare FF key, P1=0x20 means in non volatile reader memory, P2-key number
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x82;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x06;
            SendBuff[5] = 0xFF;
            SendBuff[6] = 0xFF;
            SendBuff[7] = 0xFF;
            SendBuff[8] = 0xFF;
            SendBuff[9] = 0xFF;
            SendBuff[10] = 0xFF;

            int sendLength = 11;

            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Load Key - Default Mifare FF key");

            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Load Default Mifare FF key.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Load Default Mifare FF key.";
                MessageBox.Show("ERROR: Failed to Load Default Mifare FF key.");
                return;
            }
            swLog.Flush();

            ClearTrans(0x18, request);
            ClearTrans(0x1C, request);
            ClearTrans(0x20, request);
            ClearTrans(0x24, request);
            ClearTrans(0x28, request);
            ClearTrans(0x2C, request);

            do
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    try
                    {
                        dataGridView1.Rows.Remove(row);
                    }
                    catch (Exception) { }
                }
            } while (dataGridView1.Rows.Count > 1);

            swLog.WriteLine("SUCCESS: Clear Transaction Records.");
            swLog.Flush();
            toolStripStatusLabel1.Text = "SUCCESS: Clear Transaction Records.";

            retCode = ModWinsCard.SCardDisconnect(hCard, ModWinsCard.SCARD_LEAVE_CARD);
        } // btnClearTrans()

        private void loadSampleDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadSampleData();
        }

        private int ClearInitBlocks(byte blockNumber1, byte blockNumber2, 
                                        ModWinsCard.SCARD_IO_REQUEST request)
        {
            int outBytes;
            int status;
            int sendLength;

            byte[] result = new byte[2];

            GeneralAuthenticate(blockNumber1, request);

            // Update Binary zero to blockNumber1
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = blockNumber1;     // Block number
            SendBuff[4] = 0x10;          // initSaldo

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary zeros to block " + blockNumber1.ToString() + ".");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary zeros to block " +
                                        blockNumber1.ToString() + ".");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary zeros to block " +
                                        blockNumber1.ToString() + ".";
                MessageBox.Show("ERROR: Failed to Update Binary zeros to block " +
                                        blockNumber1.ToString() + ".");
                return 1;
            }
            swLog.Flush();

            // Update Binary zeros to blockNumber2
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = blockNumber2;     // Block number
            SendBuff[4] = 0x10;             // zeros

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary zeros to block " + blockNumber2.ToString() + ".");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary zeros to block " +
                                        blockNumber2.ToString() + ".");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary zeros to block " +
                                        blockNumber2.ToString() + ".";
                MessageBox.Show("ERROR: Failed to Update Binary zeros to block " +
                                        blockNumber1.ToString() + ".");
                return 2;
            }
            swLog.Flush();

            return 0;
        }

        private int ClearBlocks(byte nextBlock, ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // byte one = 0x01;
            byte nextBlock2 = nextBlock;
            byte nextBlock3 = nextBlock;

            nextBlock2++;
            nextBlock3++;
            nextBlock3++;

            GeneralAuthenticate(nextBlock, request);

            // Update Binary to nextBlock

            // Update Binary zeros
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock;     // Block number
            SendBuff[4] = 0x10;          // initSaldo

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary zeros to block " + nextBlock.ToString() + ".");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary zeros to block " + 
                                                nextBlock.ToString() + ".");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary zeros to block " +
                                                nextBlock.ToString() + ".";
                MessageBox.Show("ERROR: Failed to Update Binary zeros to block " +
                                                nextBlock.ToString() + ".");
                return 1;
            }
            swLog.Flush();

            // Update Binary zeros to nextBlock2
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock2;       // Block number
            SendBuff[4] = 0x10;             // zeros

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary zeros to block " + nextBlock2.ToString() + ".");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary zeros to block " +
                                                nextBlock2.ToString() + ".");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary zeros to block " +
                                                nextBlock2.ToString() + ".";
                MessageBox.Show("ERROR: Failed to Update Binary zeros to block " +
                                                nextBlock2.ToString() + ".");
                return 1;
            }
            swLog.Flush();

            // Update Binary zeros to nextBlock3
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock3;       // Block number
            SendBuff[4] = 0x10;             // bobotBeras dan saldoBeras

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary zeros to block " + nextBlock3.ToString() + ".");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary zeros to block " +
                                                nextBlock3.ToString() + ".");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary zeros to block " +
                                                nextBlock3.ToString() + ".";
                MessageBox.Show("ERROR: Failed to Update Binary zeros to block " +
                                                nextBlock3.ToString() + ".");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // CleaBlocks()

        private int WriteClearCard()
        {
            int outBytes;
            int status;

            byte[] receivedUID = new byte[10];
            byte[] UID = new byte[8];
            byte[] result = new byte[2];

            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text, ModWinsCard.SCARD_SHARE_SHARED,
                    ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.Flush();
                toolStripStatusLabel1.Text = "Failed to connect to card " + readerToolStripMenuItem.Text;
                MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                return 1;
            }
            else
            {
                // MessageBox.Show("Successful connection to " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Successful connection to " + readerToolStripMenuItem.Text);
                toolStripStatusLabel1.Text = "Successful connection to " + readerToolStripMenuItem.Text;
            }

            ModWinsCard.SCARD_IO_REQUEST request = new ModWinsCard.SCARD_IO_REQUEST();
            request.dwProtocol = Protocol;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(ModWinsCard.SCARD_IO_REQUEST));

            swLog.WriteLine("Protocol: " + Protocol.ToString());

            outBytes = receivedUID.Length;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref sendBytes[0],
                sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            swLog.WriteLine("GET UID");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                UID = receivedUID.Take(outBytes - 2).ToArray();

                string hex = BitConverter.ToString(UID);
                // MessageBox.Show("UID: " + hex);
                result[0] = receivedUID[outBytes - 2];
                result[1] = receivedUID[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString());
                swLog.WriteLine("UID: " + hex + "; Response: " + hex2);
                if (hex2 == "90-00")
                {
                    swLog.WriteLine("GET UID: successful.");
                }
                else
                {
                    swLog.WriteLine("GET UID: failed.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "GET UID: failed.";
                    MessageBox.Show("GET UID: failed.");
                    return 2;
                }
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to GET UID.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to GET UID.";
                MessageBox.Show("ERROR: Failed to GET UID.");
                return 3;
            }

            swLog.Flush();

            LoadKey(request);

            ClearInitBlocks(0x01, 0x02, request);

            ClearBlocks(0x04, request);
            ClearBlocks(0x08, request);
            ClearBlocks(0x0C, request);
            ClearBlocks(0x10, request);
            ClearBlocks(0x14, request);
            ClearBlocks(0x18, request);
            ClearBlocks(0x1C, request);
            ClearBlocks(0x20, request);
            ClearBlocks(0x24, request);
            ClearBlocks(0x28, request);
            ClearBlocks(0x2C, request);

            BersihkanIsian();

            ReadTransactions(request);

            swLog.WriteLine("SUCCESS: Clear Card.");
            swLog.Flush();
            toolStripStatusLabel1.Text = "SUCCESS: Clear Card.";

            retCode = ModWinsCard.SCardDisconnect(hCard, ModWinsCard.SCARD_LEAVE_CARD);

            return 0;
        } // WriteClearCard()

        private void btnClearCard_Click(object sender, EventArgs e)
        {
            WriteClearCard();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAbout form1 = new frmAbout();

            form1.ShowDialog();

            // Determine if the OK button was clicked on the dialog box.
            if (form1.DialogResult == DialogResult.OK)
            {
                // Display a message box indicating that the OK button was clicked.
                // MessageBox.Show("The OK button on the form was clicked.");
                // Optional: Call the Dispose method when you are finished with the dialog box.
                form1.Dispose();
            } else
            {
                // MessageBox.Show("The else button on the form was clicked.");
                form1.Dispose();
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtInitSaldo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTopup_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnBacaKartu_Click(object sender, EventArgs e)
        {
            BersihkanIsian();
            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text, ModWinsCard.SCARD_SHARE_SHARED,
                                ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.Flush();
                toolStripStatusLabel1.Text = "Failed to connect to card " + readerToolStripMenuItem.Text;
                MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                return;
            }
            else
            {
                // MessageBox.Show("Successful connection to " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Successful connection to " + readerToolStripMenuItem.Text);
                toolStripStatusLabel1.Text = "Successful connection to " + readerToolStripMenuItem.Text;
            }

            // toolStripStatusLabel1.Text = "Testing...";

            byte[] receivedUID = new byte[10];
            ModWinsCard.SCARD_IO_REQUEST request = new ModWinsCard.SCARD_IO_REQUEST();
            // request.dwProtocol = 1; //SCARD_PROTOCOL_T1);
            request.dwProtocol = Protocol;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(ModWinsCard.SCARD_IO_REQUEST));
            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            swLog.WriteLine("Protocol: " + Protocol.ToString());

            int outBytes = receivedUID.Length;
            int status = ModWinsCard.SCardTransmit(hCard, ref request, ref sendBytes[0],
                sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            byte[] UID = new byte[8];
            byte[] result = new byte[2];
            swLog.WriteLine("GET UID");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                UID = receivedUID.Take(outBytes - 2).ToArray();

                string hex = BitConverter.ToString(UID);
                // MessageBox.Show("UID: " + hex);
                result[0] = receivedUID[outBytes - 2];
                result[1] = receivedUID[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString());
                swLog.WriteLine("UID: " + hex + "; Response: " + hex2);
                if (hex2 == "90-00")
                {
                    swLog.WriteLine("GET UID: successful.");
                }
                else
                {
                    swLog.WriteLine("GET UID: failed.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "GET UID: failed.";
                    MessageBox.Show("GET UID: failed.");
                    return;
                }
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to GET UID.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to GET UID.";
                MessageBox.Show("ERROR: Failed to GET UID.");
                return;
            }

            swLog.Flush();

            // Load Key - Default Mifare FF key, P1=0x20 means in non volatile reader memory, P2-key number
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x82;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x06;
            SendBuff[5] = 0xFF;
            SendBuff[6] = 0xFF;
            SendBuff[7] = 0xFF;
            SendBuff[8] = 0xFF;
            SendBuff[9] = 0xFF;
            SendBuff[10] = 0xFF;

            int sendLength = 11;

            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Load Key - Default Mifare FF key");

            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Load Default Mifare FF key.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Load Default Mifare FF key.";
                MessageBox.Show("ERROR: Failed to Load Default Mifare FF key.");
                return;
            }
            swLog.Flush();

            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x01;     // Block Number 0x01
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            // sendLength = 6;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x01");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x01.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x01.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x01.");
                return;
            }
            swLog.Flush();

            // Block 0x01; NIK
            ReadNIK(request);

            // Block 0x02 and 0x04; Nama
            ReadNama(request);

            // Block 0x05 and 0x06; Tempat Lahir
            ReadTempatLahir(request);

            // Block 0x08; Tanggal Lahir
            ReadTanggalLahir(request);

            // string strJenisKelamin = cbJenisKelamin.Text;
            // block 0x09; Jenis Kelamin
            ReadJenisKelamin(request);

            // Alamat: 16 bytes x 4
            // block 0x0A
            // skip block 0x0B
            // block 0x0C
            // block 0x0D
            // block 0x0E
            // string strAlamat = txtAlamat1.Text + txtAlamat2.Text;
            ReadAlamat(request);

            // Block 0x10 and block 0x11; Phone number; 32 bytes
            ReadPhone(request);

            // Block 0x12 and block 0x14; Email address; skip block 0x13; 32 bytes
            // Authenticate block 0x14
            ReadEmail(request);

            // Block 0x15; Tanggal Daftar
            ReadTanggalDaftar(request);

            // Block 016; Saldo
            ReadSaldo(request);

            ReadTransactions(request);

            swLog.WriteLine("SUCCESS: Baca Kartu.");
            swLog.Flush();
            toolStripStatusLabel1.Text = "SUCCESS: Baca Kartu.";

            retCode = ModWinsCard.SCardDisconnect(hCard, ModWinsCard.SCARD_LEAVE_CARD);

        } // btnBacaKartu_Click()

        // block 0x15; Tanggal Daftar
        private int WriteTanggalDaftar(string strTanggalDaftar, ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            byte[] byteTanggalDaftar= Encoding.ASCII.GetBytes(strTanggalDaftar);

            /***
            swLog.WriteLine("General Authenticate block number 0x14");

            // Write Tanggal Daftar to Block number 0x14

            // General authenticate
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x14;     // Block Number 0x14
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate.");
            }
            swLog.Flush();
            ***/

        swLog.WriteLine("Update Binary Tanggal Daftar to block number 0x15: " + strTanggalDaftar);

            // Update Binary to Block number 0x08
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x15;     // Block number 0x15
            SendBuff[4] = 0x10;     //(byte) byteTanggalDaftar.Length;

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteTanggalDaftar, 0, SendBuff, 5, 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;    // byteTanggalDaftar.Length;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Tanggal Daftar");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Tanggal Daftar.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Tanggal Daftar.";
                MessageBox.Show("ERROR: Failed to Update Binary Tanggal Daftar.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Tanggal Daftar from Block 0x15
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x15;     // Block number 0x15
            SendBuff[4] = 0x10;     // (byte)byteTanggalDaftar.Length;

            Array.Clear(RecvBuff, 0, 30);
            // RecvBuff[0] = 0;
            // RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Tanggal Daftar");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string strTanggalDaftar1 = "";
                strTanggalDaftar1 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Tanggal Daftar: " + strTanggalDaftar1);
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Tanggal Daftar.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Tanggal Daftar.";
                MessageBox.Show("ERROR: Failed to Read Binary Tanggal Daftar.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteTanggalDaftar()

        private void btnSimpan_Click(object sender, EventArgs e)
        {
		    retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text, ModWinsCard.SCARD_SHARE_SHARED,
			    				ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

			if (retCode != ModWinsCard.SCARD_S_SUCCESS)
			{
				// MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.Flush();
                toolStripStatusLabel1.Text = "Failed to connect to card " + readerToolStripMenuItem.Text;
                MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                return;
            }
			else
			{
				// MessageBox.Show("Successful connection to " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Successful connection to " + readerToolStripMenuItem.Text);
                toolStripStatusLabel1.Text = "Successful connection to " + readerToolStripMenuItem.Text;
            }

            // toolStripStatusLabel1.Text = "Testing...";
			
            byte[] receivedUID = new byte[10];
            ModWinsCard.SCARD_IO_REQUEST request = new ModWinsCard.SCARD_IO_REQUEST();
            // request.dwProtocol = 1; //SCARD_PROTOCOL_T1);
            request.dwProtocol = Protocol;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(ModWinsCard.SCARD_IO_REQUEST));
            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            swLog.WriteLine("Protocol: " + Protocol.ToString());

            int outBytes = receivedUID.Length;
            int status = ModWinsCard.SCardTransmit(hCard, ref request, ref sendBytes[0],
                sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            byte[] UID = new byte[8];
            byte[] result = new byte[2];
            swLog.WriteLine("GET UID");
            if ( status == ModWinsCard.SCARD_S_SUCCESS )
            {
                UID = receivedUID.Take(outBytes - 2).ToArray();

                string hex = BitConverter.ToString(UID);
                // MessageBox.Show("UID: " + hex);
                result[0] = receivedUID[outBytes - 2];
                result[1] = receivedUID[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString());
                swLog.WriteLine("UID: " + hex + "; Response: " + hex2);
                if ( hex2 == "90-00" )
                {
                    swLog.WriteLine("GET UID: successful.");
                } else
                {
                    swLog.WriteLine("GET UID: failed.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "GET UID: failed.";
                    MessageBox.Show("GET UID: failed.");
                    return;
                }
            } else
            {
                swLog.WriteLine("ERROR: Failed to GET UID.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to GET UID.";
                MessageBox.Show("ERROR: Failed to GET UID.");
                return;
            }

            swLog.Flush();

            LoadKey(request);

            /*****
            // Load Key - Default Mifare FF key, P1=0x20 means in non volatile reader memory, P2-key number
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x82;
            SendBuff[2] = 0x00;     // key is loaded into the reader volatile memory
            SendBuff[3] = 0x00;     // key location: 0x00
            SendBuff[4] = 0x06;
            SendBuff[5] = 0xFF;     // Default key FF FF FF FF FF FF
            SendBuff[6] = 0xFF;
            SendBuff[7] = 0xFF;
            SendBuff[8] = 0xFF;
            SendBuff[9] = 0xFF;
            SendBuff[10] = 0xFF;

            int sendLength = 11;

            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0], 
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Load Key - Default Mifare FF key");

            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Load Default Mifare FF key.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Load Default Mifare FF key.";
                MessageBox.Show("ERROR: Failed to Load Default Mifare FF key.");
                return;
            }
            swLog.Flush();
            *****/

            GeneralAuthenticate(0x01, request);

            /****
            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x01;     // Block Number 0x01
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            // sendLength = 6;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x01");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x01.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x01.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x01.");
                return;
            }
            swLog.Flush();
            ***/

            string strNIK = txtNIKWilayah.Text + txtNIKTgl.Text +
                txtNIKUrut.Text;

            if ( strNIK.Length < 16 )
            {
                MessageBox.Show("Panjang NIK kurang dari 16 digit.");
                return;
            }

            string strNama = txtNama.Text;
            if (strNama.Length == 0)
            {
                MessageBox.Show("Nama tidak boleh kosong.");
                return;
            }

            string strTempatLahir = txtTempatLahir.Text;
            if (strTempatLahir.Length == 0)
            {
                MessageBox.Show("Tempat lahir tidak boleh kosong.");
                return;
            }

            string strTglLahir = txtTglLahir.Text.Trim();
            // MessageBox.Show("tanggal lahir: #" + strTglLahir + "###");
            string strTglLahirKosong = "/  /";
            // MessageBox.Show("tanggal lahir: #" + strTglLahirKosong + "###");
            if (strTglLahir == strTglLahirKosong)
            {
                MessageBox.Show("Tanggal lahir tidak boleh kosong.");
                return;
            }

            string strAlamat1 = txtAlamat1.Text;
            string strAlamat2 = txtAlamat2.Text;

            if (strAlamat1.Length == 0)
            {
                MessageBox.Show("Alamat tidak boleh kosong.");
                return;
            }

            // Block 0x01; NIK
            WriteNIK(strNIK, request);

            // Block 0x02 and 0x04; Nama
            WriteNama(strNama, request);

            // Block 0x05 and 0x06; Tempat Lahir
            WriteTempatLahir(strTempatLahir, request);

            // Block 0x08; Tanggal Lahir
            WriteTanggalLahir(strTglLahir, request);

            string strJenisKelamin = cbJenisKelamin.Text;
            // block 0x09; Jenis Kelamin
            WriteJenisKelamin(strJenisKelamin, request);

            // Alamat: 16 bytes x 4
            // block 0x0A
            // skip block 0x0B
            // block 0x0C
            // block 0x0D
            // block 0x0E
            // string strAlamat = txtAlamat1.Text + txtAlamat2.Text;
            WriteAlamat(strAlamat1, strAlamat2, request);

            string strPhone = txtPhone.Text;
            // Block 0x10 and block 0x11; Phone number; 32 bytes
            WritePhone(strPhone, request);

            string strEmail = txtEmail.Text;
            // Block 0x12 and block 0x14; Email address; skip block 0x13; 32 bytes
            // Authenticate block 0x14
            WriteEmail(strEmail, request);

            string strTglDaftar = txtTanggalDaftar.Text;
            // Block 0x15; Tanggal Daftar
            WriteTanggalDaftar(strTglDaftar, request);
            swLog.WriteLine("SUCCESS: Simpan Data.");
            swLog.Flush();
            toolStripStatusLabel1.Text = "SUCCESS: Simpan Data.";
            // MessageBox.Show("ERROR: Failed to authenticate block 0x01.");

            retCode = ModWinsCard.SCardDisconnect(hCard, ModWinsCard.SCARD_LEAVE_CARD);
            // Ret = SCardDisconnect(hCard, SCARD_LEAVE_CARD);
        }

        public ModWinsCard.SCARD_READERSTATE RdrState;
        public ModWinsCard.SCARD_IO_REQUEST pioSendRequest;

        public Form1()
        {
            InitializeComponent();

            InitializeReader();

            logFilename = "Bansos_Masjid_Baiturrahman.log";

            swLog = new StreamWriter(logFilename);

            userReg = new UserReg();
        }

        private void InitializeReader()
        {
            // initialize smart card reader

            string ReaderList = "" + Convert.ToChar(0);
            int indx;
            int pcchReaders = 0;
            string rName = "";

            //Establish Context
            retCode = ModWinsCard.SCardEstablishContext(ModWinsCard.SCARD_SCOPE_USER, 0, 0, ref hContext);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {

                // displayOut(1, retCode, "");

                return;

            }

            // 2. List PC/SC card readers installed in the system

            retCode = ModWinsCard.SCardListReaders(this.hContext, null, null, ref pcchReaders);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {

                // displayOut(1, retCode, "");

                return;
            }

            // EnableButtons();

            byte[] ReadersList = new byte[pcchReaders];

            // Fill reader list
            retCode = ModWinsCard.SCardListReaders(this.hContext, null, ReadersList, ref pcchReaders);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // mMsg.AppendText("SCardListReaders Error: " + ModWinsCard.GetScardErrMsg(retCode));

                return;
            }
            else
            {
                // displayOut(0, 0, " ");
            }

            rName = "";
            indx = 0;

            //Convert reader buffer to string
            while (ReadersList[indx] != 0)
            {

                while (ReadersList[indx] != 0)
                {
                    rName = rName + (char)ReadersList[indx];
                    indx = indx + 1;
                }

                // MessageBox.Show("reader: " + rName);
                readerToolStripMenuItem.Text = rName;
                //Add reader name to list
                // cbReader.Items.Add(rName);
                rName = "";
                indx = indx + 1;

                break;
            }

            ConnectToReader();
        }

        private void EnableButtons()
        {

            // btnInit.Enabled = false;
            // bConnect.Enabled = true;
            // bClear.Enabled = true;

        }

        private void ConnectToReader()
        {
            // retCode = ModWinsCard.SCardConnect(hContext, cbReader.SelectedItem.ToString(), ModWinsCard.SCARD_SHARE_SHARED,
            //                       ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text, ModWinsCard.SCARD_SHARE_SHARED,
                            ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // displayOut(1, retCode, "");
            }
            else
            {
                // displayOut(0, 0, "Successful connection to " + cbReader.Text);

                // displayOut(0, 0, "Successful connection to " + readerToolStripMenuItem.Text);
            }
            connActive = true;
            // gbLoadKeys.Enabled = true;
            // gbAuth.Enabled = true;
            // gbBinOps.Enabled = true;
            // gbValBlk.Enabled = true;
            // tKeyNum.Focus();
            // rbKType1.Checked = true;
        }
    }
}
