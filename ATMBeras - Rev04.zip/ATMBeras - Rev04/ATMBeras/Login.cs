﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Globalization;
using System.Threading;

namespace Bansos_Masjid_Baiturrahman
{
    public partial class Login : Form
    {
        readonly string Username = "user";
        readonly string Password = "user";
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            this.AcceptButton = button1;  //add function Enter As button login
            //Console.WriteLine("The current UI culture: {0}", CultureInfo.CurrentUICulture.Name);
            //CultureInfo.CurrentUICulture = CultureInfo.CreateSpecificCulture("fr-fr");
            //Console.WriteLine("The current UI culture: {0}", CultureInfo.CurrentUICulture.Name);

            //System.IFormatProvider cultureUS = new System.Globalization.CultureInfo("en-US")
            //System.Globalization.CultureInfo cultureFr = new System.Globalization.CultureInfo("fr-fr");
            //CultureInfo.CurrentUICulture = CultureInfo.CreateSpecificCulture("fr-fr");


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (TxtUsername.Text == Username && TxtPassword.Text == Password)
            {
                MessageBox.Show("Kamu berhasil login");
                this.Close();

            }
            else if (TxtUsername.Text == "" || TxtPassword.Text == "")
            {
                MessageBox.Show("Kamu belum mengisi form login");

            }
            else
            {
                MessageBox.Show("Username atau Password Salah ");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit(); //exit application
        }
    }
}
