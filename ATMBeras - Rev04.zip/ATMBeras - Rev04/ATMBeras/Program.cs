﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bansos_Masjid_Baiturrahman
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login());
            Application.Run(new Form1());

        }
    }

    public class TransRecord
    {
        public string transNumber;
        public string tanggalTrans;
        public string waktuTrans;
        public string transCode;
        public string bobotBeras;
        public string saldoBeras;
    }

    enum TransCode : byte
    {
        None = 0,
        InitSaldo = 0x01,
        TopupSaldo = 0x02,
        BagiBeras = 0x03
    }

}
