﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bansos_Masjid_Baiturrahman
{
    class UserReg
    {
        public int WriteNIK(byte[] byteNIK)
        {
            // Write NIK to block 0x01, 16 bytes
            return 0;
        }

    }
}
