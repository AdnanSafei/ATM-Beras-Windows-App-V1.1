﻿
namespace Bansos_Masjid_Baiturrahman
{
    partial class frmBeras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBeras));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectReaderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.readerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblNIK = new System.Windows.Forms.Label();
            this.txtNIKWilayah = new System.Windows.Forms.TextBox();
            this.txtNama = new System.Windows.Forms.TextBox();
            this.lblNama = new System.Windows.Forms.Label();
            this.txtTempatLahir = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbJenisKelamin = new System.Windows.Forms.ComboBox();
            this.txtAlamat1 = new System.Windows.Forms.TextBox();
            this.lblAlamat = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.btnBersihkan = new System.Windows.Forms.Button();
            this.txtNIKTgl = new System.Windows.Forms.TextBox();
            this.txtNIKUrut = new System.Windows.Forms.TextBox();
            this.txtTglLahir = new System.Windows.Forms.MaskedTextBox();
            this.txtAlamat2 = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTanggalDaftar = new System.Windows.Forms.MaskedTextBox();
            this.btnTglHariIni = new System.Windows.Forms.Button();
            this.btnBacaKartu = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.label10 = new System.Windows.Forms.Label();
            this.txtSaldo = new System.Windows.Forms.TextBox();
            this.btnTopup = new System.Windows.Forms.Button();
            this.btnBagi = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Nomor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tanggal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Waktu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Transaksi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Beras = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Saldo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtTopup = new System.Windows.Forms.TextBox();
            this.txtBagi = new System.Windows.Forms.TextBox();
            this.txtInitSaldo = new System.Windows.Forms.TextBox();
            this.btnInitSaldo = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(749, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "&Menu";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectReaderToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.fileToolStripMenuItem.Text = "&Menu";
            // 
            // selectReaderToolStripMenuItem
            // 
            this.selectReaderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.readerToolStripMenuItem});
            this.selectReaderToolStripMenuItem.Name = "selectReaderToolStripMenuItem";
            this.selectReaderToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.selectReaderToolStripMenuItem.Text = "Select Reader";
            // 
            // readerToolStripMenuItem
            // 
            this.readerToolStripMenuItem.Name = "readerToolStripMenuItem";
            this.readerToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.readerToolStripMenuItem.Text = "Reader";
            // 
            // lblNIK
            // 
            this.lblNIK.AutoSize = true;
            this.lblNIK.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNIK.Location = new System.Drawing.Point(36, 41);
            this.lblNIK.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNIK.Name = "lblNIK";
            this.lblNIK.Size = new System.Drawing.Size(102, 20);
            this.lblNIK.TabIndex = 5;
            this.lblNIK.Text = "NIK (6 - 6 - 4)";
            // 
            // txtNIKWilayah
            // 
            this.txtNIKWilayah.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNIKWilayah.Location = new System.Drawing.Point(169, 42);
            this.txtNIKWilayah.Margin = new System.Windows.Forms.Padding(2);
            this.txtNIKWilayah.MaxLength = 6;
            this.txtNIKWilayah.Name = "txtNIKWilayah";
            this.txtNIKWilayah.Size = new System.Drawing.Size(92, 26);
            this.txtNIKWilayah.TabIndex = 6;
            this.txtNIKWilayah.Text = "123456";
            // 
            // txtNama
            // 
            this.txtNama.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNama.Location = new System.Drawing.Point(169, 72);
            this.txtNama.Margin = new System.Windows.Forms.Padding(2);
            this.txtNama.MaxLength = 32;
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(284, 26);
            this.txtNama.TabIndex = 10;
            this.txtNama.Text = "Agus Purwoko Tambahan Nama Panja";
            // 
            // lblNama
            // 
            this.lblNama.AutoSize = true;
            this.lblNama.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNama.Location = new System.Drawing.Point(36, 70);
            this.lblNama.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNama.Name = "lblNama";
            this.lblNama.Size = new System.Drawing.Size(117, 20);
            this.lblNama.TabIndex = 9;
            this.lblNama.Text = "Nama Lengkap";
            // 
            // txtTempatLahir
            // 
            this.txtTempatLahir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTempatLahir.Location = new System.Drawing.Point(169, 102);
            this.txtTempatLahir.Margin = new System.Windows.Forms.Padding(2);
            this.txtTempatLahir.MaxLength = 32;
            this.txtTempatLahir.Name = "txtTempatLahir";
            this.txtTempatLahir.Size = new System.Drawing.Size(284, 26);
            this.txtTempatLahir.TabIndex = 12;
            this.txtTempatLahir.Text = "Jakarta Selatan Tambahan Tempat ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(36, 105);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 20);
            this.label1.TabIndex = 11;
            this.label1.Text = "Tempat Lahir";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(469, 105);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Tgl Lahir (dd/MM/yyyy)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(36, 135);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "Jenis Kelamin";
            // 
            // cbJenisKelamin
            // 
            this.cbJenisKelamin.AutoCompleteCustomSource.AddRange(new string[] {
            "LAKI-LAKI",
            "PEREMPUAN"});
            this.cbJenisKelamin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbJenisKelamin.FormattingEnabled = true;
            this.cbJenisKelamin.Items.AddRange(new object[] {
            "LAKI-LAKI",
            "PEREMPUAN"});
            this.cbJenisKelamin.Location = new System.Drawing.Point(169, 132);
            this.cbJenisKelamin.Margin = new System.Windows.Forms.Padding(2);
            this.cbJenisKelamin.Name = "cbJenisKelamin";
            this.cbJenisKelamin.Size = new System.Drawing.Size(214, 28);
            this.cbJenisKelamin.TabIndex = 16;
            this.cbJenisKelamin.Text = "LAKI-LAKI";
            // 
            // txtAlamat1
            // 
            this.txtAlamat1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAlamat1.Location = new System.Drawing.Point(169, 163);
            this.txtAlamat1.Margin = new System.Windows.Forms.Padding(2);
            this.txtAlamat1.MaxLength = 32;
            this.txtAlamat1.Name = "txtAlamat1";
            this.txtAlamat1.Size = new System.Drawing.Size(284, 26);
            this.txtAlamat1.TabIndex = 18;
            this.txtAlamat1.Text = "Jalan Kemang 2 Blok B4 Nomor 1";
            // 
            // lblAlamat
            // 
            this.lblAlamat.AutoSize = true;
            this.lblAlamat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlamat.Location = new System.Drawing.Point(36, 163);
            this.lblAlamat.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAlamat.Name = "lblAlamat";
            this.lblAlamat.Size = new System.Drawing.Size(59, 20);
            this.lblAlamat.TabIndex = 17;
            this.lblAlamat.Text = "Alamat";
            // 
            // txtPhone
            // 
            this.txtPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhone.Location = new System.Drawing.Point(169, 222);
            this.txtPhone.Margin = new System.Windows.Forms.Padding(2);
            this.txtPhone.MaxLength = 32;
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(284, 26);
            this.txtPhone.TabIndex = 21;
            this.txtPhone.Text = "+62 812 7817 3278";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(36, 222);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 20);
            this.label6.TabIndex = 20;
            this.label6.Text = "Nomor Telpon";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(36, 285);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(157, 20);
            this.label11.TabIndex = 24;
            this.label11.Text = "Dibuat pada Tanggal";
            // 
            // btnSimpan
            // 
            this.btnSimpan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSimpan.Location = new System.Drawing.Point(163, 547);
            this.btnSimpan.Margin = new System.Windows.Forms.Padding(2);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(115, 29);
            this.btnSimpan.TabIndex = 26;
            this.btnSimpan.Text = "&Simpan Data";
            this.btnSimpan.UseVisualStyleBackColor = true;
            // 
            // btnBersihkan
            // 
            this.btnBersihkan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBersihkan.Location = new System.Drawing.Point(302, 547);
            this.btnBersihkan.Margin = new System.Windows.Forms.Padding(2);
            this.btnBersihkan.Name = "btnBersihkan";
            this.btnBersihkan.Size = new System.Drawing.Size(151, 29);
            this.btnBersihkan.TabIndex = 27;
            this.btnBersihkan.Text = "Bersihkan &Isian";
            this.btnBersihkan.UseVisualStyleBackColor = true;
            // 
            // txtNIKTgl
            // 
            this.txtNIKTgl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNIKTgl.Location = new System.Drawing.Point(272, 42);
            this.txtNIKTgl.Margin = new System.Windows.Forms.Padding(2);
            this.txtNIKTgl.MaxLength = 6;
            this.txtNIKTgl.Name = "txtNIKTgl";
            this.txtNIKTgl.Size = new System.Drawing.Size(92, 26);
            this.txtNIKTgl.TabIndex = 7;
            this.txtNIKTgl.Text = "123456";
            // 
            // txtNIKUrut
            // 
            this.txtNIKUrut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNIKUrut.Location = new System.Drawing.Point(375, 42);
            this.txtNIKUrut.Margin = new System.Windows.Forms.Padding(2);
            this.txtNIKUrut.MaxLength = 4;
            this.txtNIKUrut.Name = "txtNIKUrut";
            this.txtNIKUrut.Size = new System.Drawing.Size(78, 26);
            this.txtNIKUrut.TabIndex = 8;
            this.txtNIKUrut.Text = "1234";
            // 
            // txtTglLahir
            // 
            this.txtTglLahir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTglLahir.Location = new System.Drawing.Point(628, 102);
            this.txtTglLahir.Margin = new System.Windows.Forms.Padding(2);
            this.txtTglLahir.Mask = "00/00/0000";
            this.txtTglLahir.Name = "txtTglLahir";
            this.txtTglLahir.Size = new System.Drawing.Size(105, 26);
            this.txtTglLahir.TabIndex = 14;
            this.txtTglLahir.Text = "12071975";
            this.txtTglLahir.ValidatingType = typeof(System.DateTime);
            // 
            // txtAlamat2
            // 
            this.txtAlamat2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAlamat2.Location = new System.Drawing.Point(169, 193);
            this.txtAlamat2.Margin = new System.Windows.Forms.Padding(2);
            this.txtAlamat2.MaxLength = 32;
            this.txtAlamat2.Name = "txtAlamat2";
            this.txtAlamat2.Size = new System.Drawing.Size(284, 26);
            this.txtAlamat2.TabIndex = 19;
            this.txtAlamat2.Text = "Bekasi Barat, Kota Bekasi";
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(169, 251);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2);
            this.txtEmail.MaxLength = 32;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(284, 26);
            this.txtEmail.TabIndex = 23;
            this.txtEmail.Text = "apurwoko@gmail.com";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(36, 251);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 20);
            this.label4.TabIndex = 22;
            this.label4.Text = "Email";
            // 
            // txtTanggalDaftar
            // 
            this.txtTanggalDaftar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTanggalDaftar.Location = new System.Drawing.Point(203, 283);
            this.txtTanggalDaftar.Margin = new System.Windows.Forms.Padding(2);
            this.txtTanggalDaftar.Mask = "00/00/0000";
            this.txtTanggalDaftar.Name = "txtTanggalDaftar";
            this.txtTanggalDaftar.Size = new System.Drawing.Size(105, 26);
            this.txtTanggalDaftar.TabIndex = 28;
            this.txtTanggalDaftar.Text = "12071975";
            this.txtTanggalDaftar.ValidatingType = typeof(System.DateTime);
            // 
            // btnTglHariIni
            // 
            this.btnTglHariIni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTglHariIni.Location = new System.Drawing.Point(326, 280);
            this.btnTglHariIni.Margin = new System.Windows.Forms.Padding(2);
            this.btnTglHariIni.Name = "btnTglHariIni";
            this.btnTglHariIni.Size = new System.Drawing.Size(80, 29);
            this.btnTglHariIni.TabIndex = 29;
            this.btnTglHariIni.Text = "Hari Ini";
            this.btnTglHariIni.UseVisualStyleBackColor = true;
            // 
            // btnBacaKartu
            // 
            this.btnBacaKartu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBacaKartu.Location = new System.Drawing.Point(479, 547);
            this.btnBacaKartu.Margin = new System.Windows.Forms.Padding(2);
            this.btnBacaKartu.Name = "btnBacaKartu";
            this.btnBacaKartu.Size = new System.Drawing.Size(115, 29);
            this.btnBacaKartu.TabIndex = 30;
            this.btnBacaKartu.Text = "&Baca Kartu";
            this.btnBacaKartu.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(469, 166);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 20);
            this.label5.TabIndex = 31;
            this.label5.Text = "(max 32 huruf)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(471, 197);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 20);
            this.label7.TabIndex = 32;
            this.label7.Text = "(max 32 huruf)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(471, 226);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 20);
            this.label8.TabIndex = 33;
            this.label8.Text = "(max 32 huruf)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(471, 255);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 20);
            this.label9.TabIndex = 34;
            this.label9.Text = "(max 32 huruf)";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 590);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.statusStrip1.Size = new System.Drawing.Size(749, 22);
            this.statusStrip1.TabIndex = 35;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(48, 17);
            this.toolStripStatusLabel1.Text = "Ready...";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(42, 357);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(127, 20);
            this.label10.TabIndex = 36;
            this.label10.Text = "Saldo Beras (kg)";
            // 
            // txtSaldo
            // 
            this.txtSaldo.Enabled = false;
            this.txtSaldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSaldo.Location = new System.Drawing.Point(199, 354);
            this.txtSaldo.Margin = new System.Windows.Forms.Padding(2);
            this.txtSaldo.MaxLength = 8;
            this.txtSaldo.Name = "txtSaldo";
            this.txtSaldo.Size = new System.Drawing.Size(87, 26);
            this.txtSaldo.TabIndex = 37;
            // 
            // btnTopup
            // 
            this.btnTopup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTopup.Location = new System.Drawing.Point(472, 285);
            this.btnTopup.Margin = new System.Windows.Forms.Padding(2);
            this.btnTopup.Name = "btnTopup";
            this.btnTopup.Size = new System.Drawing.Size(140, 29);
            this.btnTopup.TabIndex = 38;
            this.btnTopup.Text = "&Topup Saldo (kg)";
            this.btnTopup.UseVisualStyleBackColor = true;
            // 
            // btnBagi
            // 
            this.btnBagi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBagi.Location = new System.Drawing.Point(472, 324);
            this.btnBagi.Margin = new System.Windows.Forms.Padding(2);
            this.btnBagi.Name = "btnBagi";
            this.btnBagi.Size = new System.Drawing.Size(140, 29);
            this.btnBagi.TabIndex = 39;
            this.btnBagi.Text = "Bagi Be&ras (kg)";
            this.btnBagi.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Nomor,
            this.Tanggal,
            this.Waktu,
            this.Transaksi,
            this.Beras,
            this.Saldo});
            this.dataGridView1.Location = new System.Drawing.Point(40, 399);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(674, 135);
            this.dataGridView1.TabIndex = 40;
            // 
            // Nomor
            // 
            this.Nomor.HeaderText = "Nomor";
            this.Nomor.MinimumWidth = 6;
            this.Nomor.Name = "Nomor";
            this.Nomor.Width = 125;
            // 
            // Tanggal
            // 
            this.Tanggal.HeaderText = "Tanggal";
            this.Tanggal.MinimumWidth = 6;
            this.Tanggal.Name = "Tanggal";
            this.Tanggal.Width = 125;
            // 
            // Waktu
            // 
            this.Waktu.HeaderText = "Waktu";
            this.Waktu.MinimumWidth = 6;
            this.Waktu.Name = "Waktu";
            this.Waktu.Width = 125;
            // 
            // Transaksi
            // 
            this.Transaksi.HeaderText = "Transaksi";
            this.Transaksi.MinimumWidth = 6;
            this.Transaksi.Name = "Transaksi";
            this.Transaksi.Width = 125;
            // 
            // Beras
            // 
            this.Beras.HeaderText = "Bobot Beras";
            this.Beras.MinimumWidth = 6;
            this.Beras.Name = "Beras";
            this.Beras.Width = 125;
            // 
            // Saldo
            // 
            this.Saldo.HeaderText = "Saldo Beras";
            this.Saldo.MinimumWidth = 6;
            this.Saldo.Name = "Saldo";
            this.Saldo.Width = 125;
            // 
            // txtTopup
            // 
            this.txtTopup.Enabled = false;
            this.txtTopup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTopup.Location = new System.Drawing.Point(628, 288);
            this.txtTopup.Margin = new System.Windows.Forms.Padding(2);
            this.txtTopup.MaxLength = 8;
            this.txtTopup.Name = "txtTopup";
            this.txtTopup.Size = new System.Drawing.Size(87, 26);
            this.txtTopup.TabIndex = 41;
            // 
            // txtBagi
            // 
            this.txtBagi.Enabled = false;
            this.txtBagi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBagi.Location = new System.Drawing.Point(628, 327);
            this.txtBagi.Margin = new System.Windows.Forms.Padding(2);
            this.txtBagi.MaxLength = 8;
            this.txtBagi.Name = "txtBagi";
            this.txtBagi.Size = new System.Drawing.Size(87, 26);
            this.txtBagi.TabIndex = 42;
            // 
            // txtInitSaldo
            // 
            this.txtInitSaldo.Enabled = false;
            this.txtInitSaldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInitSaldo.Location = new System.Drawing.Point(199, 324);
            this.txtInitSaldo.Margin = new System.Windows.Forms.Padding(2);
            this.txtInitSaldo.MaxLength = 8;
            this.txtInitSaldo.Name = "txtInitSaldo";
            this.txtInitSaldo.Size = new System.Drawing.Size(87, 26);
            this.txtInitSaldo.TabIndex = 44;
            this.txtInitSaldo.TextChanged += new System.EventHandler(this.txtInitSaldo_TextChanged);
            // 
            // btnInitSaldo
            // 
            this.btnInitSaldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInitSaldo.Location = new System.Drawing.Point(44, 322);
            this.btnInitSaldo.Margin = new System.Windows.Forms.Padding(2);
            this.btnInitSaldo.Name = "btnInitSaldo";
            this.btnInitSaldo.Size = new System.Drawing.Size(140, 29);
            this.btnInitSaldo.TabIndex = 43;
            this.btnInitSaldo.Text = "I&nit Saldo (kg)";
            this.btnInitSaldo.UseVisualStyleBackColor = true;
            this.btnInitSaldo.Click += new System.EventHandler(this.btnInitSaldo_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(534, 595);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 13);
            this.label12.TabIndex = 45;
            this.label12.Text = "Sys. Language";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(622, 595);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(93, 13);
            this.textBox1.TabIndex = 46;
            // 
            // frmBeras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 612);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtInitSaldo);
            this.Controls.Add(this.btnInitSaldo);
            this.Controls.Add(this.txtBagi);
            this.Controls.Add(this.txtTopup);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnBagi);
            this.Controls.Add(this.btnTopup);
            this.Controls.Add(this.txtSaldo);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnBacaKartu);
            this.Controls.Add(this.btnTglHariIni);
            this.Controls.Add(this.txtTanggalDaftar);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtAlamat2);
            this.Controls.Add(this.txtTglLahir);
            this.Controls.Add(this.txtNIKUrut);
            this.Controls.Add(this.txtNIKTgl);
            this.Controls.Add(this.btnBersihkan);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAlamat1);
            this.Controls.Add(this.lblAlamat);
            this.Controls.Add(this.cbJenisKelamin);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTempatLahir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.lblNama);
            this.Controls.Add(this.txtNIKWilayah);
            this.Controls.Add(this.lblNIK);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmBeras";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bansos Masjid Baiturrahman - Registration";
            this.Load += new System.EventHandler(this.frmBeras_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectReaderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem readerToolStripMenuItem;
        private System.Windows.Forms.Label lblNIK;
        private System.Windows.Forms.TextBox txtNIKWilayah;
        private System.Windows.Forms.TextBox txtNama;
        private System.Windows.Forms.Label lblNama;
        private System.Windows.Forms.TextBox txtTempatLahir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbJenisKelamin;
        private System.Windows.Forms.TextBox txtAlamat1;
        private System.Windows.Forms.Label lblAlamat;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.Button btnBersihkan;
        private System.Windows.Forms.TextBox txtNIKTgl;
        private System.Windows.Forms.TextBox txtNIKUrut;
        private System.Windows.Forms.MaskedTextBox txtTglLahir;
        private System.Windows.Forms.TextBox txtAlamat2;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox txtTanggalDaftar;
        private System.Windows.Forms.Button btnTglHariIni;
        private System.Windows.Forms.Button btnBacaKartu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtSaldo;
        private System.Windows.Forms.Button btnTopup;
        private System.Windows.Forms.Button btnBagi;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtTopup;
        private System.Windows.Forms.TextBox txtBagi;
        private System.Windows.Forms.TextBox txtInitSaldo;
        private System.Windows.Forms.Button btnInitSaldo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nomor;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tanggal;
        private System.Windows.Forms.DataGridViewTextBoxColumn Waktu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Transaksi;
        private System.Windows.Forms.DataGridViewTextBoxColumn Beras;
        private System.Windows.Forms.DataGridViewTextBoxColumn Saldo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox1;
    }
}