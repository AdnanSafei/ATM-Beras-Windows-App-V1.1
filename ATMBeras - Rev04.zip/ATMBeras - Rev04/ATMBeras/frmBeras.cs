﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Threading;

namespace Bansos_Masjid_Baiturrahman
{
    public partial class frmBeras : Form
    {
        public int retCode, hContext, hCard, Protocol;
        public bool connActive = false;
        public bool autoDet;
        public byte[] SendBuff = new byte[263];
        public byte[] RecvBuff = new byte[263];
        public int SendLen, RecvLen, nBytesRet, reqType, Aprotocol, dwProtocol, cbPciLength;
        public string logFilename = "";

        public StreamWriter swLog;

        byte[] TransNumberBlocks = new byte[5];

        TransRecord[] transRecords = new TransRecord[5];

        string[] TransCodeString = { "None", "Init Saldo", "Topup Saldo", "Bagi Beras" };



        private void ConnectToReader()
        {
            // retCode = ModWinsCard.SCardConnect(hContext, cbReader.SelectedItem.ToString(), ModWinsCard.SCARD_SHARE_SHARED,
            //                       ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text, ModWinsCard.SCARD_SHARE_SHARED,
                            ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // displayOut(1, retCode, "");
            }
            else
            {
                // displayOut(0, 0, "Successful connection to " + cbReader.Text);

                // displayOut(0, 0, "Successful connection to " + readerToolStripMenuItem.Text);
            }
            connActive = true;
            // gbLoadKeys.Enabled = true;
            // gbAuth.Enabled = true;
            // gbBinOps.Enabled = true;
            // gbValBlk.Enabled = true;
            // tKeyNum.Focus();
            // rbKType1.Checked = true;
        }

        private void InitializeReader()
        {
            // initialize smart card reader

            string ReaderList = "" + Convert.ToChar(0);
            int indx;
            int pcchReaders = 0;
            string rName = "";

            //Establish Context
            retCode = ModWinsCard.SCardEstablishContext(ModWinsCard.SCARD_SCOPE_USER, 0, 0, ref hContext);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {

                // displayOut(1, retCode, "");

                return;

            }

            // 2. List PC/SC card readers installed in the system

            retCode = ModWinsCard.SCardListReaders(this.hContext, null, null, ref pcchReaders);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {

                // displayOut(1, retCode, "");

                return;
            }

            // EnableButtons();

            byte[] ReadersList = new byte[pcchReaders];

            // Fill reader list
            retCode = ModWinsCard.SCardListReaders(this.hContext, null, ReadersList, ref pcchReaders);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // mMsg.AppendText("SCardListReaders Error: " + ModWinsCard.GetScardErrMsg(retCode));

                return;
            }
            else
            {
                // displayOut(0, 0, " ");
            }

            rName = "";
            indx = 0;

            //Convert reader buffer to string
            while (ReadersList[indx] != 0)
            {

                while (ReadersList[indx] != 0)
                {
                    rName = rName + (char)ReadersList[indx];
                    indx = indx + 1;
                }

                // MessageBox.Show("reader: " + rName);
                readerToolStripMenuItem.Text = rName;
                //Add reader name to list
                // cbReader.Items.Add(rName);
                rName = "";
                indx = indx + 1;

                break;
            }

            ConnectToReader();
        }

        public frmBeras()
        {
            InitializeComponent();

            InitializeReader();

            logFilename = "Bansos_Masjid_Baiturrahman.log";

            swLog = new StreamWriter(logFilename);

        }

        private void frmBeras_Load(object sender, EventArgs e)
        {
            Console.WriteLine("The current UI culture: {0}", CultureInfo.CurrentUICulture.Name);
            CultureInfo.CurrentUICulture = CultureInfo.CreateSpecificCulture("fr-fr");
            Console.WriteLine("The current UI culture: {0}", CultureInfo.CurrentUICulture.Name);
            textBox1.Text = (CultureInfo.CurrentUICulture.Name);

            //System.IFormatProvider cultureUS = new System.Globalization.CultureInfo("en-US")
            //System.Globalization.CultureInfo cultureFr = new System.Globalization.CultureInfo("fr-fr");
            //CultureInfo.CurrentUICulture = CultureInfo.CreateSpecificCulture("fr-fr");
        }

        private void txtInitSaldo_TextChanged(object sender, EventArgs e)
        {

        }

        private int ReadCardInit()
        {
            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text, ModWinsCard.SCARD_SHARE_SHARED,
                    ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1, ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.Flush();
                toolStripStatusLabel1.Text = "Failed to connect to card " + readerToolStripMenuItem.Text;
                MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                return 1;
            }
            else
            {
                // MessageBox.Show("Successful connection to " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Successful connection to " + readerToolStripMenuItem.Text);
                toolStripStatusLabel1.Text = "Successful connection to " + readerToolStripMenuItem.Text;
            }

            // toolStripStatusLabel1.Text = "Testing...";

            byte[] receivedUID = new byte[10];
            ModWinsCard.SCARD_IO_REQUEST request = new ModWinsCard.SCARD_IO_REQUEST();
            // request.dwProtocol = 1; //SCARD_PROTOCOL_T1);
            request.dwProtocol = Protocol;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(ModWinsCard.SCARD_IO_REQUEST));
            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            swLog.WriteLine("Protocol: " + Protocol.ToString());

            int outBytes = receivedUID.Length;
            int status = ModWinsCard.SCardTransmit(hCard, ref request, ref sendBytes[0],
                sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            byte[] UID = new byte[8];
            byte[] result = new byte[2];
            swLog.WriteLine("GET UID");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                UID = receivedUID.Take(outBytes - 2).ToArray();

                string hex = BitConverter.ToString(UID);
                // MessageBox.Show("UID: " + hex);
                result[0] = receivedUID[outBytes - 2];
                result[1] = receivedUID[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString());
                swLog.WriteLine("UID: " + hex + "; Response: " + hex2);
                if (hex2 == "90-00")
                {
                    swLog.WriteLine("GET UID: successful.");
                }
                else
                {
                    swLog.WriteLine("GET UID: failed.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "GET UID: failed.";
                    MessageBox.Show("GET UID: failed.");
                    return 2;
                }
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to GET UID.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to GET UID.";
                MessageBox.Show("ERROR: Failed to GET UID.");
                return 3;
            }

            swLog.Flush();

            // Load Key - Default Mifare FF key, P1=0x20 means in non volatile reader memory, P2-key number
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x82;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x06;
            SendBuff[5] = 0xFF;
            SendBuff[6] = 0xFF;
            SendBuff[7] = 0xFF;
            SendBuff[8] = 0xFF;
            SendBuff[9] = 0xFF;
            SendBuff[10] = 0xFF;

            int sendLength = 11;

            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Load Key - Default Mifare FF key");

            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Load Default Mifare FF key.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Load Default Mifare FF key.";
                MessageBox.Show("ERROR: Failed to Load Default Mifare FF key.");
                return 4;
            }
            swLog.Flush();

            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x01;     // Block Number 0x01
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            // sendLength = 6;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x01");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x01.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x01.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x01.");
                return 5;
            }
            swLog.Flush();
            toolStripStatusLabel1.Text = "SUCCESS: ReadCardInit().";

            return 0;
        } // ReadCardInit()

        private int GeneralAuthenticate(byte blockNumber, ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = blockNumber;     // Block Number
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x" + blockNumber.ToString("X2"));
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                            "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x" + blockNumber.ToString("X2"));
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x" + blockNumber.ToString("X2");
                MessageBox.Show("ERROR: Failed to authenticate block 0x" + blockNumber.ToString("X2"));
                return 1;
            }
            swLog.Flush();

            return 0;
        } // GeneralAuthenticate(byte blockNumber)

        int ReadTransNum(byte blockNumber, ModWinsCard.SCARD_IO_REQUEST request,
                    ref UInt32 lastTransNumber, ref byte lastBlock)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // Read Binary from blockNumber
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = blockNumber; // blockNumber; 0x2C
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Last Transaction Number");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteNumber = new byte[4];
                lastBlock = RecvBuff[4];

                Buffer.BlockCopy(RecvBuff, 0, byteNumber, 0, 4);

                lastTransNumber = BitConverter.ToUInt32(byteNumber, 0);

                swLog.WriteLine("Read Binary Last Transaction Number " + lastTransNumber.ToString());
                swLog.WriteLine("Read Binary Last Block " + lastBlock.ToString());
                // txtSaldo.Text = dSaldo.ToString();
                // MessageBox.Show("Read Binary Init Saldo " + dSaldo.ToString());
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Last Transaction Number.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Last Transaction Number.";
                MessageBox.Show("ERROR: Failed to Read Binary Last Transaction Number.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadTransNum()

        private int ReadTransRecord(int idx, byte blockNumber,
                    ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            int retCode;
            byte nextBlock2;
            byte nextBlock3;

            nextBlock2 = blockNumber;
            nextBlock3 = blockNumber;

            nextBlock2++;
            nextBlock3++;
            nextBlock3++;

            retCode = GeneralAuthenticate(blockNumber, request);

            // Read Binary transNumber dan tanggal from nextBlock
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = blockNumber; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary transNumber dan tanggal.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteNumber2 = new byte[4];
                byte[] byteTanggal2 = new byte[12];

                Array.Clear(byteTanggal2, 0, 12);

                Buffer.BlockCopy(RecvBuff, 0, byteNumber2, 0, 4);
                Buffer.BlockCopy(RecvBuff, 4, byteTanggal2, 0, 12);

                UInt32 transNumber2 = BitConverter.ToUInt32(byteNumber2, 0);
                string strTanggal2 = Encoding.ASCII.GetString(byteTanggal2, 0, 10);

                swLog.WriteLine("Read Binary transNumber " + transNumber2.ToString());
                swLog.WriteLine("Read Binary tanggal " + strTanggal2);

                transRecords[idx].transNumber = transNumber2.ToString();
                transRecords[idx].tanggalTrans = strTanggal2;

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary transNumber dan tanggal.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary transNumber dan tanggal.";
                MessageBox.Show("ERROR: Failed to Read Binary transNumber dan tanggal.");
                return 1;
            }
            swLog.Flush();

            // Read Binary waktu dan transCode from nextBlock2
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock2; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary waktu dan transCode.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteWaktu2 = new byte[12];

                Array.Clear(byteWaktu2, 0, 12);

                Buffer.BlockCopy(RecvBuff, 0, byteWaktu2, 0, 12);

                byte byteCode2 = RecvBuff[12];

                string strWaktu2 = Encoding.ASCII.GetString(byteWaktu2, 0, 8);

                swLog.WriteLine("Read Binary waktu " + strWaktu2);
                swLog.WriteLine("Read Binary transCode " + byteCode2.ToString());

                transRecords[idx].waktuTrans = strWaktu2;
                transRecords[idx].transCode = TransCodeString[byteCode2];

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary waktu dan transCode.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary waktu dan transCode.";
                MessageBox.Show("ERROR: Failed to Read Binary waktu dan transCode.");
                return 1;
            }
            swLog.Flush();

            // Read Binary bobotBeras dan saldoBeras from nextBlock3
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock3; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary bobotBeras dan saldoBeras.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteBobotBeras2 = new byte[8];

                Array.Clear(byteBobotBeras2, 0, 8);
                Buffer.BlockCopy(RecvBuff, 0, byteBobotBeras2, 0, 8);
                double bobotBeras2 = BitConverter.ToDouble(byteBobotBeras2, 0);

                byte[] byteSaldoBeras2 = new byte[8];

                Array.Clear(byteSaldoBeras2, 0, 8);
                Buffer.BlockCopy(RecvBuff, 8, byteSaldoBeras2, 0, 8);
                double saldoBeras2 = BitConverter.ToDouble(byteSaldoBeras2, 0);

                swLog.WriteLine("Read Binary bobotBeras " + bobotBeras2.ToString("0.00") +
                                    ", saldoBeras " + saldoBeras2.ToString("0.00"));

                transRecords[idx].bobotBeras = bobotBeras2.ToString("0.00");
                transRecords[idx].saldoBeras = saldoBeras2.ToString("0.00");

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary bobotBeras dan saldoBeras.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary bobotBeras dan saldoBeras.";
                MessageBox.Show("ERROR: Failed to Read Binary bobotBeras dan saldoBeras.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // ReadTransRecord()

        private void PopulateDataGridView()
        {

            string[] row0 = {   transRecords[0].transNumber, transRecords[0].tanggalTrans,
                                transRecords[0].waktuTrans, transRecords[0].transCode,
                                transRecords[0].bobotBeras, transRecords[0].saldoBeras };

            string[] row1 = {   transRecords[1].transNumber, transRecords[1].tanggalTrans,
                                transRecords[1].waktuTrans, transRecords[1].transCode,
                                transRecords[1].bobotBeras, transRecords[1].saldoBeras };

            string[] row2 = {   transRecords[2].transNumber, transRecords[2].tanggalTrans,
                                transRecords[2].waktuTrans, transRecords[2].transCode,
                                transRecords[2].bobotBeras, transRecords[2].saldoBeras };

            string[] row3 = {   transRecords[3].transNumber, transRecords[3].tanggalTrans,
                                transRecords[3].waktuTrans, transRecords[3].transCode,
                                transRecords[3].bobotBeras, transRecords[3].saldoBeras };

            string[] row4 = {   transRecords[4].transNumber, transRecords[4].tanggalTrans,
                                transRecords[4].waktuTrans, transRecords[4].transCode,
                                transRecords[4].bobotBeras, transRecords[4].saldoBeras };

            dataGridView1.Rows.Add(row0);
            dataGridView1.Rows.Add(row1);
            dataGridView1.Rows.Add(row2);
            dataGridView1.Rows.Add(row3);
            dataGridView1.Rows.Add(row4);

            dataGridView1.Columns[0].DisplayIndex = 0;
            dataGridView1.Columns[1].DisplayIndex = 1;
            dataGridView1.Columns[2].DisplayIndex = 2;
            dataGridView1.Columns[3].DisplayIndex = 3;

            // songsDataGridView.Columns[0].DisplayIndex = 3;
            // songsDataGridView.Columns[1].DisplayIndex = 4;
            // songsDataGridView.Columns[2].DisplayIndex = 0;
            // songsDataGridView.Columns[3].DisplayIndex = 1;
            // songsDataGridView.Columns[4].DisplayIndex = 2;

        } // PopulateDataGridView()

        private int WriteTransaction(byte nextBlock, UInt32 transNumber, string tanggal,
                        string waktu, TransCode transCode,
                        double bobotBeras, double saldoBeras,
                        ModWinsCard.SCARD_IO_REQUEST request)
        {
            int status;
            int sendLength;
            int outBytes;
            byte[] result = new byte[2];

            // byte one = 0x01;
            byte nextBlock2 = nextBlock;
            byte nextBlock3 = nextBlock;

            nextBlock2++;
            nextBlock3++;
            nextBlock3++;

            GeneralAuthenticate(nextBlock, request);

            swLog.WriteLine("WriteTransaction(" + nextBlock.ToString() + ", " +
                                transNumber.ToString() + ", " + tanggal + ", " +
                                waktu + ", " + transCode.ToString() + ", " +
                                bobotBeras.ToString("0.00") + ", " +
                                saldoBeras.ToString("0.00"));

            // Update Binary to nextBlock
            // nextTransNumber (4 bytes) and tanggal (12 bytes)

            // nextTransNumber (4 bytes)
            byte[] byteTransNumber = BitConverter.GetBytes(transNumber);
            byte[] byteTanggal = Encoding.ASCII.GetBytes(tanggal);

            // Update Binary nextTransNumber to nextBlock
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock;     // Block number
            SendBuff[4] = 0x10;          // initSaldo

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            // nextTransNumber (4 bytes)
            Buffer.BlockCopy(byteTransNumber, 0, SendBuff, 5, 4);

            // tanggal (12 bytes)
            Buffer.BlockCopy(byteTanggal, 0, SendBuff, 9, byteTanggal.Length);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary transNumber dan tanggal");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary transNumber dan tanggal.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary transNumber dan tanggal.";
                MessageBox.Show("ERROR: Failed to Update Binary transNumber dan tanggal.");
                return 1;
            }
            swLog.Flush();

            // Read Binary transNumber dan tanggal from nextBlock
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary transNumber dan tanggal.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteNumber2 = new byte[4];
                byte[] byteTanggal2 = new byte[12];

                Array.Clear(byteTanggal2, 0, 12);

                Buffer.BlockCopy(RecvBuff, 0, byteNumber2, 0, 4);
                Buffer.BlockCopy(RecvBuff, 4, byteTanggal2, 0, 12);

                UInt32 transNumber2 = BitConverter.ToUInt32(byteNumber2, 0);
                string strTanggal2 = Encoding.ASCII.GetString(byteTanggal2, 0, 10);

                // double dSaldo = BitConverter.ToDouble(byteSaldo, 0);
                // string strNIK2 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary transNumber " + transNumber2.ToString());
                swLog.WriteLine("Read Binary tanggal " + strTanggal2);
                // txtSaldo.Text = dSaldo.ToString();
                // MessageBox.Show("Read Binary Init Saldo " + dSaldo.ToString());
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary transNumber dan tanggal.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary transNumber dan tanggal.";
                MessageBox.Show("ERROR: Failed to Read Binary transNumber dan tanggal.");
                return 1;
            }
            swLog.Flush();

            // Update Binary waktu (12 bytes) and TransCode (4 bytes) to nextBlock2
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock2;       // Block number
            SendBuff[4] = 0x10;             // waktu and TransCode

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            byte[] byteWaktu = Encoding.ASCII.GetBytes(waktu);

            // waktu 12 bytes
            Buffer.BlockCopy(byteWaktu, 0, SendBuff, 5, byteWaktu.Length);

            byte byteCode = (byte)transCode;

            // 5 + 12 = 17
            SendBuff[17] = byteCode;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary waktu dan transCode");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary waktu dan transCode.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary waktu dan transCode.";
                MessageBox.Show("ERROR: Failed to Update Binary waktu dan transCode.");
                return 1;
            }
            swLog.Flush();

            // Read Binary waktu dan transCode from nextBlock2
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock2; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary waktu dan transCode.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteWaktu2 = new byte[12];

                Array.Clear(byteWaktu2, 0, 12);

                Buffer.BlockCopy(RecvBuff, 0, byteWaktu2, 0, 12);

                byte byteCode2 = RecvBuff[12];

                string strWaktu2 = Encoding.ASCII.GetString(byteWaktu2, 0, 8);

                swLog.WriteLine("Read Binary waktu " + strWaktu2);
                swLog.WriteLine("Read Binary transCode " + byteCode2.ToString());

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary waktu dan transCode.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary waktu dan transCode.";
                MessageBox.Show("ERROR: Failed to Read Binary waktu dan transCode.");
                return 1;
            }
            swLog.Flush();

            // Update Binary bobotBeras (8 bytes) and saldoBeras (8 bytes) to nextBlock3
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock3;       // Block number
            SendBuff[4] = 0x10;             // bobotBeras dan saldoBeras

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            byte[] byteBobotBeras = BitConverter.GetBytes(bobotBeras);
            // bobotBeras 8 bytes; double
            Buffer.BlockCopy(byteBobotBeras, 0, SendBuff, 5, 8);

            // saldoBeras 8 bytes; double
            byte[] byteSaldoBeras = BitConverter.GetBytes(saldoBeras);
            Buffer.BlockCopy(byteSaldoBeras, 0, SendBuff, 13, 8);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary bobotBeras dan saldoBeras");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary bobotBeras dan saldoBeras.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary bobotBeras dan saldoBeras.";
                MessageBox.Show("ERROR: Failed to Update Binary bobotBeras dan saldoBeras.");
                return 1;
            }
            swLog.Flush();

            // Read Binary bobotBeras dan saldoBeras from nextBlock3
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = nextBlock3; // Block number
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary bobotBeras dan saldoBeras.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteBobotBeras2 = new byte[8];

                Array.Clear(byteBobotBeras2, 0, 8);
                Buffer.BlockCopy(RecvBuff, 0, byteBobotBeras2, 0, 8);
                double bobotBeras2 = BitConverter.ToDouble(byteBobotBeras2, 0);

                byte[] byteSaldoBeras2 = new byte[8];

                Array.Clear(byteSaldoBeras2, 0, 8);
                Buffer.BlockCopy(RecvBuff, 8, byteSaldoBeras2, 0, 8);
                double saldoBeras2 = BitConverter.ToDouble(byteSaldoBeras2, 0);

                swLog.WriteLine("Read Binary bobotBeras " + bobotBeras2.ToString("0.00") +
                                    ", saldoBeras " + saldoBeras2.ToString("0.00"));

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary bobotBeras dan saldoBeras.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary bobotBeras dan saldoBeras.";
                MessageBox.Show("ERROR: Failed to Read Binary bobotBeras dan saldoBeras.");
                return 1;
            }
            swLog.Flush();

            GeneralAuthenticate(0x2C, request);

            // Update Binary transNumber (4 bytes) and lastBlock (1 byte) to 0x2C
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x2C;       // Block number 0x2C
            SendBuff[4] = 0x10;       // transNumber and lastBlock

            byte lastBlock = nextBlock;

            // Block Data
            Array.Clear(SendBuff, 5, 20);

            // transNumber, 4 bytes
            Buffer.BlockCopy(byteTransNumber, 0, SendBuff, 5, 4);

            // lastBlock, 1 byte
            SendBuff[9] = lastBlock;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary transNumber dan lastBlock");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary transNumber dan lastBlock.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary transNumber dan lastBlock.";
                MessageBox.Show("ERROR: Failed to Update Binary transNumber dan lastBlock.");
                return 1;
            }
            swLog.Flush();

            // Read Binary transNumber dan lastBlock from 0x2C
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x2C; // Block number 0x2C
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary transNumber dan lastBlock.");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteTransNumber2 = new byte[4];

                Array.Clear(byteTransNumber2, 0, 4);
                Buffer.BlockCopy(RecvBuff, 0, byteTransNumber2, 0, 4);
                UInt32 transNumber3 = BitConverter.ToUInt32(byteTransNumber2, 0);

                byte lastBlock2 = RecvBuff[5];

                swLog.WriteLine("Read Binary transNumber " + transNumber3.ToString() +
                                    ", lastBlock " + lastBlock2.ToString());

                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary transNumber dan lastBlock.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary transNumber dan lastBlock.";
                MessageBox.Show("ERROR: Failed to Read Binary transNumber dan lastBlock.");
                return 1;
            }
            swLog.Flush();

            return 0;
        } // WriteTransaction()

        private int ReadTransactions(ModWinsCard.SCARD_IO_REQUEST request)
        {
            int retCode;
            // block 0x1C, 0x20, 0x24, 0x28, 0x2C;
            byte[] blockNumbers = new byte[5];

            blockNumbers[0] = 0x1C;
            blockNumbers[1] = 0x20;
            blockNumbers[2] = 0x24;
            blockNumbers[3] = 0x28;
            blockNumbers[4] = 0x2C;

            for (int i = 0; i < 5; i++)
            {
                retCode = ReadTransRecord(i, blockNumbers[i], request);
            }

            PopulateDataGridView();
            return 0;
        } // ReadTransactions()

        private int WriteInitSaldo(double initSaldo)
        {
            retCode = ModWinsCard.SCardConnect(hContext, readerToolStripMenuItem.Text,
                ModWinsCard.SCARD_SHARE_SHARED,
                ModWinsCard.SCARD_PROTOCOL_T0 | ModWinsCard.SCARD_PROTOCOL_T1,
                ref hCard, ref Protocol);

            if (retCode != ModWinsCard.SCARD_S_SUCCESS)
            {
                // MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Failed to connect to card " + readerToolStripMenuItem.Text);
                swLog.Flush();
                toolStripStatusLabel1.Text = "Failed to connect to card " + readerToolStripMenuItem.Text;
                MessageBox.Show("Failed to connect to card " + readerToolStripMenuItem.Text);
                return 1;
            }
            else
            {
                // MessageBox.Show("Successful connection to " + readerToolStripMenuItem.Text);
                swLog.WriteLine("Successful connection to " + readerToolStripMenuItem.Text);
                toolStripStatusLabel1.Text = "Successful connection to " + readerToolStripMenuItem.Text;
            }

            // toolStripStatusLabel1.Text = "Testing...";

            byte[] receivedUID = new byte[10];
            ModWinsCard.SCARD_IO_REQUEST request = new ModWinsCard.SCARD_IO_REQUEST();
            // request.dwProtocol = 1; //SCARD_PROTOCOL_T1);
            request.dwProtocol = Protocol;
            request.cbPciLength = System.Runtime.InteropServices.Marshal.SizeOf(typeof(ModWinsCard.SCARD_IO_REQUEST));
            byte[] sendBytes = new byte[] { 0xFF, 0xCA, 0x00, 0x00, 0x00 }; //get UID command      for Mifare cards

            swLog.WriteLine("Protocol: " + Protocol.ToString());

            int outBytes = receivedUID.Length;
            int status = ModWinsCard.SCardTransmit(hCard, ref request, ref sendBytes[0],
                sendBytes.Length, ref request, ref receivedUID[0], ref outBytes);

            byte[] UID = new byte[8];
            byte[] result = new byte[2];
            swLog.WriteLine("GET UID");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                UID = receivedUID.Take(outBytes - 2).ToArray();

                string hex = BitConverter.ToString(UID);
                // MessageBox.Show("UID: " + hex);
                result[0] = receivedUID[outBytes - 2];
                result[1] = receivedUID[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString());
                swLog.WriteLine("UID: " + hex + "; Response: " + hex2);
                if (hex2 == "90-00")
                {
                    swLog.WriteLine("GET UID: successful.");
                }
                else
                {
                    swLog.WriteLine("GET UID: failed.");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "GET UID: failed.";
                    MessageBox.Show("GET UID: failed.");
                    return 2;
                }
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to GET UID.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to GET UID.";
                MessageBox.Show("ERROR: Failed to GET UID.");
                return 3;
            }

            swLog.Flush();

            // Load Key - Default Mifare FF key, P1=0x20 means in non volatile reader memory, P2-key number
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x82;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x06;
            SendBuff[5] = 0xFF;
            SendBuff[6] = 0xFF;
            SendBuff[7] = 0xFF;
            SendBuff[8] = 0xFF;
            SendBuff[9] = 0xFF;
            SendBuff[10] = 0xFF;

            int sendLength = 11;

            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Load Key - Default Mifare FF key");

            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Load Default Mifare FF key.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Load Default Mifare FF key.";
                MessageBox.Show("ERROR: Failed to Load Default Mifare FF key.");
                return 4;
            }
            swLog.Flush();

            // General Authenticate - Read the documents mentioned in the README :)
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0x86;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x00;
            SendBuff[4] = 0x05;
            SendBuff[5] = 0x01;
            SendBuff[6] = 0x00;
            SendBuff[7] = 0x14;     // Block Number 0x14
            SendBuff[8] = 0x60;
            SendBuff[9] = 0x00;

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 10;
            // sendLength = 6;
            outBytes = 255;
            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                            sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            // memcpy(pbSend, "\xFF\x86\x00\x00\x05\x01\x00\x01\x60\x00", 10);

            swLog.WriteLine("General Authenticate Block 0x14");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to authenticate block 0x14.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to authenticate block 0x14.";
                MessageBox.Show("ERROR: Failed to authenticate block 0x14.");
                return 5;
            }
            swLog.Flush();

            // Update Binary initSaldo to Block number 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xD6;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16;     // Block number 0x16
            SendBuff[4] = 0x10;     // initSaldo

            byte[] byteInitSaldoTemp = BitConverter.GetBytes(initSaldo);

            // Block Data
            Array.Clear(SendBuff, 5, 20);
            Buffer.BlockCopy(byteInitSaldoTemp, 0, SendBuff, 5, 8);

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 21;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Update Binary Init Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Update Binary Init Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Update Binary Init Saldo.";
                MessageBox.Show("ERROR: Failed to Update Binary Init Saldo.");
                return 1;
            }
            swLog.Flush();

            // Read Binary Saldo, block 0x16
            SendBuff[0] = 0xFF;
            SendBuff[1] = 0xB0;
            SendBuff[2] = 0x00;
            SendBuff[3] = 0x16; // Block 0x16; Saldo
            SendBuff[4] = 0x10;

            RecvBuff[0] = 0;
            RecvBuff[1] = 0;
            sendLength = 5;
            outBytes = 255;

            status = ModWinsCard.SCardTransmit(hCard, ref request, ref SendBuff[0],
                sendLength, ref request, ref RecvBuff[0], ref outBytes);

            // https://github.com/hidglobal/mifare-sample/blob/master/MifareTest.cpp

            swLog.WriteLine("Read Binary Init Saldo");
            if (status == ModWinsCard.SCARD_S_SUCCESS)
            {
                swLog.WriteLine("outBytes: " + outBytes);
                result[0] = RecvBuff[outBytes - 2];
                result[1] = RecvBuff[outBytes - 1];

                byte[] byteSaldo = new byte[8];

                Buffer.BlockCopy(RecvBuff, 0, byteSaldo, 0, 8);

                double dSaldo = BitConverter.ToDouble(byteSaldo, 0);
                // string strNIK2 = Encoding.ASCII.GetString(RecvBuff.Take(outBytes - 2).ToArray());
                swLog.WriteLine("Read Binary Init Saldo " + dSaldo.ToString());
                txtSaldo.Text = dSaldo.ToString();
                // MessageBox.Show("Read Binary Init Saldo " + dSaldo.ToString());
                string hex1 = BitConverter.ToString(RecvBuff.Take(outBytes).ToArray());
                swLog.WriteLine("RecvBuff: " + hex1);
                string hex2 = BitConverter.ToString(result);
                swLog.WriteLine("outBytes: " + outBytes.ToString() +
                    "; Response: " + hex2);
            }
            else
            {
                swLog.WriteLine("ERROR: Failed to Read Binary Init Saldo.");
                swLog.Flush();
                toolStripStatusLabel1.Text = "ERROR: Failed to Read Binary Init Saldo.";
                MessageBox.Show("ERROR: Failed to Read Binary Init Saldo.");
                return 1;
            }
            swLog.Flush();

            // General Authenticate block 0x2C
            GeneralAuthenticate(0x02C, request);

            // Read last transaction number from block 0x2C

            UInt32 lastTransNumber = 0;
            byte lastBlock = 0;

            retCode = ReadTransNum(0x2C, request, ref lastTransNumber, ref lastBlock);

            UInt32 nextTransNumber = lastTransNumber + 1;
            byte nextBlock = 0;

            if (lastBlock == 0)
            {
                nextBlock = TransNumberBlocks[0];
            }
            else
            {
                for (int i = 0; i < 5; i++)
                {
                    if (lastBlock == TransNumberBlocks[i])
                    {
                        if (i == 4)
                        {
                            nextBlock = TransNumberBlocks[0];
                            break;
                        }
                        else
                        {
                            nextBlock = TransNumberBlocks[i + 1];
                            break;
                        }
                    }
                }
            }

            DateTime time = DateTime.Now;
            string tanggal;
            string waktu;
            tanggal = time.ToString("dd/MM/yyyy");
            waktu = time.ToString("HH:mm:ss");

            WriteTransaction(nextBlock, nextTransNumber, tanggal, waktu,
                                TransCode.InitSaldo, initSaldo, initSaldo, request);

            ReadTransactions(request);

            return 0;
        } // WriteInitSaldo()

        private void btnInitSaldo_Click(object sender, EventArgs e)
        {
            int rc;

            if (btnInitSaldo.Text == "I&nit Saldo (kg)")
            {
                rc = ReadCardInit();
                if (rc != 0)
                {
                    swLog.WriteLine("ERROR: Failed to ReadCardInit().");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "ERROR: Failed to ReadCardInit().";
                    MessageBox.Show("ERROR: Failed to ReadCardInit().");
                }
                else
                {
                    txtInitSaldo.Enabled = true;
                    btnInitSaldo.Text = "Apply Init (kg)";
                    txtInitSaldo.Text = "";
                    txtInitSaldo.Focus();
                }
            }
            else if (btnInitSaldo.Text == "Apply Init (kg)")
            {
                if (txtInitSaldo.Text == "")
                {
                    txtInitSaldo.Enabled = false;
                    btnInitSaldo.Text = "I&nit Saldo (kg)";
                    return;
                }

                double initSaldo = double.Parse(txtInitSaldo.Text);
                initSaldo = Math.Round(initSaldo, 2);

                rc = WriteInitSaldo(initSaldo);
                if (rc != 0)
                {
                    swLog.WriteLine("ERROR: Failed to WriteInitSaldo().");
                    swLog.Flush();
                    toolStripStatusLabel1.Text = "ERROR: Failed to WriteInitSaldo().";
                    txtInitSaldo.Enabled = false;
                    btnInitSaldo.Text = "I&nit Saldo (kg)";
                    return;
                }
                toolStripStatusLabel1.Text = "SUCCESS: Init Saldo.";

                // read current balance
                // ReadSaldo();
                // add topup to current balance
                // write current balance to card

                txtInitSaldo.Enabled = false;
                txtInitSaldo.Text = "";
                btnInitSaldo.Text = "I&nit Saldo (kg)";
            }
        } // btnInitSaldo_Click()
    }
}
